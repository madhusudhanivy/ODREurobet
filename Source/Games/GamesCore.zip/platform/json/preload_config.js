var preloadConfig = {
    "sentry": {
        "sentryEnabled" : false,
        "sentryApiKey" : "https://fdd401ba482a4f20b969855dd34575f0@sentry.io/1425130"
    },
    "logoBrand": {
        "customLogoOverBrandingEnabled": false,
        "customLogoGameEnabled": true,
        "vendorGameName": "skywind",
        "vendorGameLogoFormat": ".gif"
    }
}