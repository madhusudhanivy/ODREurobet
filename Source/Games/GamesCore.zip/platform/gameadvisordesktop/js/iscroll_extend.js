
var linearEasing = {
    style: 'cubic-bezier(0,0,1,1)',
    fn: function (k) { return k; }
};

function CustomIScroll(el, options){
    this.originUseTransition = options.useTransition;
    IScroll.apply(this,arguments);
}
CustomIScroll.prototype.constructor = CustomIScroll;
CustomIScroll.prototype = Object.create(IScroll.prototype);

CustomIScroll.prototype.isTransitionSupported = function(){
    return this.originUseTransition && this.options.useTransform;
};

CustomIScroll.prototype.stop = function(){
    this.isAnimating = false;
    var position = this.getComputedPosition();
    var x = position.x;
    this._translate(x,0);
};

CustomIScroll.prototype.scrollToLeft = function(time){
    this.scrollTo(0, 0, time * Math.abs(this.x) / 1000 , linearEasing);
};

CustomIScroll.prototype.scrollToRight = function(time){
    this.scrollTo(this.maxScrollX, 0, time * (Math.abs(this.maxScrollX) - Math.abs(this.x))/1000
        , linearEasing);
};