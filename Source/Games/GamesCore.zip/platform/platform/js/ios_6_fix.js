/** @author  asoroka, tmaslov */

function is_IOS6_orLower() {
    if (/iP(hone|od|ad)/.test(navigator.platform)) {
        // supports iOS 2.0 and later: <http://bit.ly/TJjs1V>
        var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
        var version = [parseInt(v[1], 10), parseInt(v[2], 10), parseInt(v[3] || 0, 10)];
        if(version[0] < 7){
            return true
        }
    }
    return false;
}

if (is_IOS6_orLower()) {

    function requestFrame(e) {
        setTimeout(e, 40); // 25 fps
    }

    // overwrite existing method
    if (self.requestAnimationFrame) {
        self.requestAnimationFrame = self.requestFrame;
    }
    if (self.mozRequestAnimationFrame) {
        self.mozRequestAnimationFrame = self.requestFrame;
    }
    if (self.webkitRequestAnimationFrame) {
        self.webkitRequestAnimationFrame = self.requestFrame;
    }

    // overwrite parent's functions if it exists
    if (self.parent) {
        if (parent.requestAnimationFrame) {
            parent.requestAnimationFrame = self.requestFrame;
        }
        if (parent.mozRequestAnimationFrame) {
            parent.mozRequestAnimationFrame = self.requestFrame;
        }
        if (parent.webkitRequestAnimationFrame) {
            parent.webkitRequestAnimationFrame = self.requestFrame;
        }
    }

    function overwriteRequestFrame() {
        var i;

        // overwrite those methods for all frames
        for (i = 0; i < self.frames.length; i++) {
            if (self.frames[i].requestAnimationFrame) {
                self.frames[i].requestAnimationFrame = self.requestFrame;
            }
            if (self.frames[i].mozRequestAnimationFrame) {
                self.frames[i].mozRequestAnimationFrame = self.requestFrame;
            }
            if (self.frames[i].webkitRequestAnimationFrame) {
                self.frames[i].webkitRequestAnimationFrame = self.requestFrame;
            }
        }
    }

    // Wait while adding frames
    setTimeout(overwriteRequestFrame, 10000);

}