/**
 * Created by antononi on 12/10/16.
 */

var LOG = console.log.bind(console, '%c [ OFFLINE SERVER ] ', 'background: #d00; color: #fff; font-weight: bold');

var GET = (function() {
    var get = {};
    var t = location.href.split('#')[0].split('?', 2)[1];
    if (t) {
        var pairs = t.split('&');
        for (var i = 0; i < pairs.length; ++i) {
            var p = pairs[i].split('=', 2);
            if (p[0])
                get[p[0].toLowerCase()] = p[1];
        }
    }
    return {
        param: function (name, def) {
            name = name.toLowerCase();
            return get[name] === undefined && def !== undefined ? def : get[name];
        },
        intParam: function (name, def) {
            return parseInt(this.param(name, def));
        },
        floatParam: function (name, def) {
            return parseFloat(this.param(name, def));
        },
        boolParam: function (name, def) {
            return this.param(name, def) == 'true';
        }
    };
})();

var MODEL = {
    realBalance: GET.floatParam('realBalance', 1000) * 100,
    gameBonusBalance: GET.floatParam('gameBonusBalance', 1000) * 100,
    fsbBalance: GET.intParam('fsbBalance', 0),
    transferredCents: GET.intParam('transferredCents', 0),
    transferredFsb: GET.intParam('transferredFsb', 0),
    transactionSuccess: GET.boolParam('transactionSuccess', true),
    fsbPrice: GET.intParam('fsbPrice', 1),
    spinError: GET.boolParam('spinError', false)
};

var typeOf = (function() {
    var PREFIX_LENGTH = '[object '.length;
    return function (obj) {
        return Object.prototype.toString.apply(obj).slice(PREFIX_LENGTH, -1);
    };
})();

processors = {};
socket.send = function(msg){
    LOG('Received ' + msg);
    var json = JSON.parse(msg);
    var processor = processors[json.ID];
    var responses = [];
    if(processor) {
        responses = processor(json);
        if(!responses)
            responses = [];
        else if(typeOf(responses) != 'Array')
            responses = [responses];
    } else
        LOG('Processor not found for ' + json.ID);
    for(var i = 0; i < responses.length; ++i) {
        var msg = typeOf(responses[i]) == 'String' ? responses[i] : JSON.stringify(responses[i]);
        LOG('Replying ' + msg);
        setTimeout(SOCKET_MESSAGE_EMIT.bind(window, msg), 0);
    }
};

var createBaseError = function() {
    return {
        errorCode: 6,
        message: 'ERR_SYSTEM',
        commandCode: 0,
        commandName: ''
    };
};

var transactionFailedError = function() {
    return {
        data:{
            errorCode:129,
            errorParams:[
                "message",
                "Hai raggiunto il limite di puntata da te impostato, clicca su \"Esci\" per chiudere il gioco. Verifica le impostazioni nella sezione Gioco Responsabile del tuo profilo",
                "displayType",
                "{info}",
                "messageId",
                "ltm_err5_rg_limit_reached",
                "behaviour",
                ""
            ]
        },
        ID:40744,
        umid:31
    };
};


// SystemLoginRequest(10000), SystemLoginWithTokenRequest(10001)
processors[10000] = processors[10001] = function(msg) {
    return [
        // SystemLoginResponse(10002)
        {
            ID: 10002,
            token: {
                secretKey: 'SECRET',
                userName: msg.userName,
                currency: 'EUR',
                balance: MODEL.realBalance
            }
        },
        // SystemUserBalanceNotification(10006)
        {
            ID: 10006,
            balanceInfo: {
                clientType: "casino",
                totalBalance: MODEL.realBalance,
                currency: "EUR",
                balanceChange: 0
            }
        },
        // CasinoGameDynamicBalanceChangeNotification(40085)
        {
            ID: 40085,
            data: {
                typeBalance: 0,
                currency: "EUR",
                balanceInCents: MODEL.realBalance,
                deltaBalanceInCents: 0
            }
        },
        // CasinoItalyGameListInfoNotification(40382)
        {
            ID: 40382,
            data: {
                params: [
                    "ashbmbg",  "2",            "ashjah",   "2",            "ba",       "2",
                    "batfree",  "2",            "batpen",   "2",            "batrid",   "2",
                    "bib",      "2",            "bj_mh5",   "2",            "bjto",     "2",
                    "bl",       "2",            "car",      "2",            "cheaa",    "2",
                    "ct",       "2",            "dt",       "2",            "eas",      "2",
                    "er",       "2",            "fdt",      "2",
                    "fow",      "2",            "glrj",     "2",            "gts102",   "2",
                    "gts263",   "2",            "gts269",   "2",            "gts394",   "2",
                    "gts621",   "2",            "gts631",   "2",            "gtsbtg",   "2",
                    "gtsdgk",   "2",            "gtsdnc",   "2",            "gtssprs",  "2",
                    "hb",       "2",            "hilop",    "2",            "hlf",      "2",
                    "jpgt",     "2",            "kkg",      "2",            "legwld",   "2",
                    "lm",       "2",            "lndg",     "2",            "mcb",      "2",
                    "mcln",     "2",            "mfor",     "2",            "mmbj",     "2",
                    "mobbj",    "2",            "mobdt",    "2",            "mobro",    "2",
                    "mrn_eu",   "2",            "msgs",     "2",            "pnp",      "2",
                    "po",       "2",            "rng2",     "2",            "ro",       "2",
                    "ro101",    "2",            "sis",      "2",            "sol",      "2",
                    "spm",      "2",            "spmj",     "2",
                    "tontl",    "0",            "tpd2",     "2",            "vf29",     "2",
                    "vf5238",   "2",            "whk",      "2"
                ]
            }
        }
    ];
};

var defaultUrl = 'https://pp.vk.me/c630520/v630520118/4764a/niYqU2xqRbc.jpg';
// SystemGetUrlsRequest(10010)
processors[10010] = function(msg) {
    var urls = {};
    for(var i = 0; i < msg.urlTypes.length; ++i)
        urls[msg.urlTypes[i]] = [
            {
                url: defaultUrl,
                priority: 1
            }
        ];
    // SystemGetUrlsResponse(10011)
    return {
        ID: 10011,
        data: {
            urls: urls
        }
    }
};
// UMSGetURLSRequest(31031)
processors[31031] = function(msg) {
    var urlList = [];
    for(var i = 0; i < msg.urlTypeList.length; ++i)
        urlList.push({
            urlType: msg.urlTypeList[i],
            url: defaultUrl,
            priority: 1
        });
    // UMSGetURLSResponse(31032)
    return {
        ID: 31032,
        data: {
            urlList: urlList
        }
    };
};

// CasinoKillWindowSessionRequest(40294)
processors[40294] = function() {
    // CasinoCloseSingleInstanceGameDuplicateResponse(40292)
    return {
        ID: 40292,
        data: {
            brokenGameCode: 0
        }
    };
};

// CasinoBrokenGamesListRequest(40036)
processors[40036] = function() {
    // CasinoBrokenGamesListResponse(40037)
    return {
        ID: 40037,
        data: {
            brokenGames: [

            ]
        }
    };
};

// CasinoReserveBrokenGamesRequest(40030)
processors[40030] = function() {
    // CasinoReserveBrokenGamesResponse(40031)
    return {
        ID: 40031,
        data: {}
    };
};

// CasinoGameLimitsRequest(40024)
processors[40024] = function(msg) {
    var rouletteLimit = {
        minBet: 0,
        maxBet: 100000000
    };
    // CasinoGameLimitsResponse(40025)
    return {
        ID: 40025,
        data: {
            funNoticeGames: 0,
            funNoticePayouts: 0,
            gameGroup: msg.gameShortName,
            minBet: 0,
            maxBet: 100000000,
            minPosBet: 0,
            maxPosBet: 100000000,
            coinSizes: [1, 2, 3, 4, 5, 10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100, 200, 300, 400, 500, 1000, 1500, 2000, 3000, 5000, 10000]//,
            /*rouletteLimits: [
             {
             tableLimitsName: '',
             infoAlternative: [],
             limits: {
             STRAIGHT_LIMIT: rouletteLimit,
             FIFTY_FIFTY_LIMIT: rouletteLimit,
             COLUMN_AND_DOZEN_LIMIT: rouletteLimit,
             TABLE_LIMIT: rouletteLimit,
             DOUBLE_STREET_LIMIT: rouletteLimit
             }
             }
             ],
             sidebetLimits: {
             playerMinBet: 0,
             playerMaxBet: 100000000,
             dealerMinBet: 0,
             dealerMaxBet: 100000000,
             twentyOnePlusThreeMinBet: 0,
             twentyOnePlusThreeMaxBet: 100000000
             },
             altLimits: []*/
        }
    };
};

// CasinoSlotGameLoginRequest(40020), CasinoTableGameLoginRequest(40050)
processors[40020] = processors[40050] = function() {
    return [
        // CasinoRegulatorLoginResponse(40079)
        {
            ID: 40079,
            data: {
                tableSessionCode: 123456,
                aamsCode: 'AAMS_CODE',
                ropCode: '',
                ropDate: '',
                totalTransferAmountInCents: MODEL.transferredCents,
                totalTransferFSBs: MODEL.transferredFsb
            }
        },
        // CasinoGameLoginResponse(40026)
        {
            ID: 40026,
            data: {
                credit: MODEL.realBalance
            }
        }
    ];
};

var cheats = [];
var prefixLength = 'test '.length;
// CasinoChatRequest(40039)
processors[40039] = function(msg) {
    var t = msg.chatMessage.slice(prefixLength).split(',');
    var cheat = [];
    for(var i = 0; i < t.length; ++i)
        cheat.push(parseInt(t[i]));
    cheats.push(cheat);
};

// CasinoSpinRequest(40021)
processors[40021] = function() {
    return MODEL.spinError ?
        // CasinoSpinErrorResponse(40023)
    {
        ID: 40023,
        data: createBaseError()
    } :
        // CasinoSpinResponse(40022)
    {
        ID: 40022,
        data: {
            credit: 0,
            results: cheats.length > 0 ? cheats.pop() : [0, 0, 0, 0, 0]
        }
    };
};

// CasinoFreeSpinsBonusRequest(40092)
processors[40092] = function() {
    // CasinoFreeSpinsBonusResponse(40093)
    return {
        ID: 40093,
        data: {}
    };
};

// CasinoFreeSpinsBonusCoinsizeRequest(40095)
processors[40095] = function() {
    // CasinoFreeSpinsBonusCoinsizeResponse(40096)
    return {
        ID: 40096,
        data: {
            fsbCoinsize: ["" + MODEL.fsbPrice, "1", "1"]
        }
    };
};

// ********** ITALY start **********

// CasinoGetBonusesByContextRequest(48465)
processors[48465] = function() {
    // CasinoGetBonusesByContextResponse(48466)
    return {
        ID: 48466,
        data: {
            monetaryBalance: MODEL.realBalance / 100,
            funBalance: MODEL.gameBonusBalance / 100,
            fsbBalance: MODEL.fsbBalance
        }
    };
};

// CasinoTableMoneyTransactionRequest(40082)
processors[40082] = function(msg) {
    return MODEL.transactionSuccess ? [
        // CasinoTabelBalanceResponse(40080)
        {
            ID: 40080,
            data: {
                tableSessionCode: '123456',
                aamsCode: 'AAMS_CODE',
                ropCode: 'ROP_CODE',
                ropTimestamp: '0',
                balanceVersion: 0,
                balanceChange: msg.amountInCents,
                balance: msg.amountInCents,
                freeSpinsCount: msg.freeSpinsCount
            }
        },
        // CasinoRegulatorLoginResponse(40079)
        {
            ID: 40079,
            data: {
                tableSessionCode: 123456,
                aamsCode: 'AAMS_CODE',
                ropCode: '',
                ropDate: '',
                totalTransferAmountInCents: msg.amountInCents,
                totalTransferFSBs: msg.freeSpinsCount
            }
        },
        // CasinoTableMoneyTransactionResponse(40081)
        {
            ID: 40081,
            data: {
                aamsCode: 'AAMS_CODE',
                lastRopCode: 'LAST_ROP_CODE',
                lastRopDate: '',
                totalTransferAmountInCents: msg.amountInCents,
                totalTransferFSBs: msg.freeSpinsCount
            }
        }
    ] : [
        // CasinoTableMoneyTransactionErrorResponse(40084)
        transactionFailedError()
    ];
};

// ********** ITALY end **********

socket.isOpenCustom = true;
SOCKET_CONNECT_EMIT();