/* IOS */

/**
 * The console object is only activated when the Dev Toolbar is opened on IE9. In other case CP failing on start,
 * because trying to use undefined object for logging.
 *
 * See https://portal-jira.playtech.corp/browse/NGM-51801
 * See https://portal-jira.playtech.corp/browse/NGM-51963
 *
 */
if((typeof console) == 'undefined') {
    console={};
    console.log = function(){};
    console.debug = function(){};
    console.info = function(){};
    console.error = function(){};
    console.trace = function(){};
    console.fatal = function(){};
}


if (typeof Object.create != 'function') {
    // Production steps of ECMA-262, Edition 5, 15.2.3.5
    // Reference: http://es5.github.io/#x15.2.3.5
    Object.create = (function() {
        // To save on memory, use a shared constructor
        function Temp() {}

        // make a safe reference to Object.prototype.hasOwnProperty
        var hasOwn = Object.prototype.hasOwnProperty;

        return function (O) {
            // 1. If Type(O) is not Object or Null throw a TypeError exception.
            if (typeof O != 'object') {
                throw TypeError('Object prototype may only be an Object or null');
            }

            // 2. Let obj be the result of creating a new object as if by the
            //    expression new Object() where Object is the standard built-in
            //    constructor with that name
            // 3. Set the [[Prototype]] internal property of obj to O.
            Temp.prototype = O;
            var obj = new Temp();
            Temp.prototype = null; // Let's not keep a stray reference to O...

            // 4. If the argument Properties is present and not undefined, add
            //    own properties to obj as if by calling the standard built-in
            //    function Object.defineProperties with arguments obj and
            //    Properties.
            if (arguments.length > 1) {
                // Object.defineProperties does ToObject on its first argument.
                var Properties = Object(arguments[1]);
                for (var prop in Properties) {
                    if (hasOwn.call(Properties, prop)) {
                        obj[prop] = Properties[prop];
                    }
                }
            }

            // 5. Return obj
            return obj;
        };
    })();
}

/**
 *  matchMedia is unsupported on IE9
 */
if(typeof window.matchMedia == "undefined"){
    window.matchMedia = function(){
        return false;
    }
}

/**
 * This script is needed by Safari browser on iPhone devices and all other browsers that using back-forward cache.
 * So when user navigates back, safari trying to load complete state of page saved in the cache
 *
 * See https://portal-jira.playtech.corp/browse/NGM-49098
 *
 * @param event
 */
window.onpageshow = function(event) {
    if (event.persisted) {
        window.location.reload()
    }
};
/**
 *  Performance polifill 
 */
(function(){
    window.performance = {};
    if(!Date.now){
        Date.now = function(){
            return new Date().getTime();
        }
    }
})();

/**
 * Event constructor polyfill
 * See https://portal-jira.playtech.corp/browse/NGM-154385, https://portal-jira.playtech.corp/browse/NGM-155466
 */
(function (window) {
    try {
        new window.Event("Test");
    } catch(error) {
        function Event(typeArg, eventInit) {
            eventInit = eventInit || { bubbles: false, cancelable: false };
            var event = window.document.createEvent("Event");
            event.initEvent(typeArg, eventInit.bubbles, eventInit.cancelable);
            return event;
        }
        Event.prototype = window.Event.prototype;

        function CustomEvent(typeArg, customEventInit) {
            customEventInit = customEventInit || { bubbles: false, cancelable: false, detail: undefined };
            var event = window.document.createEvent("CustomEvent");
            event.initEvent(typeArg, customEventInit.bubbles, customEventInit.cancelable);
            event.detail = customEventInit.detail;
            event.initCustomEvent = function(type, canBubble, cancelable, detail) {
                event.initEvent(type, canBubble, cancelable);
                event.detail = detail;
            };
            return event;
        }
        CustomEvent.prototype = window.Event.prototype;

        window.Event = Event;
        window.CustomEvent = CustomEvent;
    }
})(window);
