/**
 * This script contains all viewport-related logic. It scales viewport when <head> section is parsed. Also it contains
 * objects and methods for device/browser detections required in context of this script's logic.
 *
 * The main strategy for viewport scaling is to make all devices to scale and report real physical resolution, except
 * those which has hi-resolution screens (e.g. Full HD+, Retina+). For the latest different strategies applies (e.g.
 * for Retina iPad scaling applies to make it report same resolution as non-retina iPad (1024px),
 * for Androids with Full HD - to make them report 1280px resolution). This is business requirement
 * as old NGM Games don't have hi-res layouts for games...
 *
 * See ViewportManager.createViewport() method for strategy details.
 *
 * @author Andriy Halyasovskyy
 * @version 15.01.15
 *
 * =====================================================================================================================
 * Release notes:
 *
 * 15.01.15
 * - Added support for Native Wrapper at Samsung Galaxy S4 LTE (GT-I9505)
 * - Added support for old Chrome 25 version
 * - Added support for UCBrowser
 *
 * 14.10.21
 * - Added support for iPhone 6 and 6 Plus
 *
 * 14.07.11
 * - Added support for all Android Native Wrappers
 *
 * 14.07.04
 * - Complete re-architecture to switch from exceptional target-dpi map to exceptional device map
 * - Added support for Webkit browsers at LG G2 and Samsung Note 3 Android 4.3
 */

var magicViewportContent1 = "target-densitydpi=320, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0";
var magicViewportContent2 = "user-scalable=no, initial-scale=1.0, maximum-scale=0.5, minimum-scale=0.5";
var magicViewportContent3 = "user-scalable=no, initial-scale=1.0, maximum-scale=0.75, minimum-scale=0.75";

var Constants = {
    //Source: http://en.wikipedia.org/wiki/Comparison_of_Android_devices + iOS devices + 801 for Samsung Galaxy S & S2
    //as they report 534*1.5=801; read about this constant in Screen.selectClosestResolution()
    mobileDevicesUniqueResolutions : [2560, 2048, 1920, 1440, 1334, 1280, 1136, 1024, 960, 854, 801, 800, 640, 480, 400, 320],
    fullHDWidth : 1920,
    highResScreenThreshold : 1920,
    maxAndroidSupportedResolution : 1280,
    maxIpadSupportedResolution : 1024,
    oldChromeVersionThreshold : 25, //read about this constant in Screen.convertFromDipsToPx()

    exceptionalDevices: {
        "Android 4\\.3.+SM-N900.+Version" : magicViewportContent1, //Samsung Galaxy Note 3 Android 4.3 Webkit browser
        "GT-I9505.+Version(?!.+Chrome)" : magicViewportContent1, //Samsung Galaxy S4 LTE Native Wrapper
        "HTC.One.+Version(?!.+Chrome)" : magicViewportContent1, //HTC One Webkit browser
        "HTC.One.+Version.+Chrome" : magicViewportContent2, //HTC One Wrapper
        "LG-D802.+Version" : magicViewportContent2, //LG G2 Webkit browser,
        "Android(?!.+Nexus (?:7|10))(?=.+Version\/4.0.+Chrome)" : magicViewportContent2, //Android Native Wrapper except Nexus 7 and 10
        "Android.+Nexus 7.+Version.+Chrome" : magicViewportContent3 //Android Native Wrapper exact in Nexus 7 2013
    }
};

/*
 NB: When using RegExp constructor function, the normal string escape rules (preceding special characters with \
 when included in a string) are necessary. For example, the following are equivalent:
 var re = /\w+/;
 var re = new RegExp("\\w+");
 https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp

 Also use these resources for developing/debugging regular expressions http://www.regexr.com and https://regex101.com
 */

// =====================================================================================================================

var Logger = (function() {
    return {
        logDelimiterLine: function() {
            this.log("----------------------------------------------------------------");
        },

        log: function(message) {
            if (console) {console.info("[INFO] [viewport.js] " + message);}
        }
    };
})();

/**
 * Creates viewport. Contains private low-level method to create meta tag and add it to DOM and contains public hi-level
 * methods to create viewport with different required content.
 */
var Viewport = (function() {
    /**
     * Need to be called when <head> section is parsed as for iOS devices (at least) it don't take effect right away if
     * called onLoad (e.g. GWT EntryPoint.onModuleLoad())
     */
    /*private*/ function createViewport(content) {
        Logger.logDelimiterLine();
        Logger.log("Creating viewport with next content: " + content);
        Logger.logDelimiterLine();

        var viewportMetaTag = document.createElement('meta');
        viewportMetaTag.setAttribute("id", "viewport");
        viewportMetaTag.setAttribute("name", "viewport");
        viewportMetaTag.setAttribute("content", content);

        document.getElementsByTagName("head")[0].appendChild(viewportMetaTag);
    }

    return {
        /**
         * As Web-standards evolve this universal viewport settings should work correctly for major modern mobile OS's
         * and browsers, see: http://dev.w3.org/csswg/css-device-adapt/#viewport-meta
         */
        setViewport: function(scale) {
            this.scale = scale;
            createViewport("user-scalable=no, " +
                "initial-scale=" + scale + ", maximum-scale=" + scale + ", minimum-scale=" + scale);
        },

        /**
         * This method targeted for Androids with Android WebKit browser in which initial-scale works incorrectly.
         * Setting target-densitydpi=device-dpi makes viewport scaling to real physical resolution of device,
         * see: http://developer.android.com/guide/webapps/targeting.html#ViewportDensity
         * Setting initial, min, max-scale together with target-densitydpi is required to ensure user won't scale the
         * page manually as it was found that user-scalable=no doesn't work correctly on all devices...
         *
         * Support for Android specific target-densitydpi property has being removed from WebKit,
         * see: http://trac.webkit.org/changeset/119527 so this is only for old browsers.
         *
         * Also then NGM Core will rely on window.outerWidth/Height for Android to find-out resolution which is best
         * choice as it ignores browser address bar (as it will be hidden after game loaded with window.scrollTo(0, 1)).
         */
        setViewportAndroidWebkit: function(targetDpi) {
            createViewport("target-densitydpi=" + targetDpi + ", user-scalable=no, " +
                "initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0");
        },

        /**
         * This would be as first check before any logic of viewport.js. If device is in exceptional devices map - then
         * just take the viewport content from this map and apply. The end.
         */
        setViewportExceptionalDevice: function(content) {
            createViewport(content);
        },

        getViewportValue: function() {
            return this.scale;
        }
    };
})();

// --------------------------------------------------------------------------------------------------------------------

/**
 * Contains detection methods for different devices, os's, browsers, modes, screen characteristics, etc.
 */
var Device = (function() {
    return {
        testUserAgent: function(regExp) {
            return regExp.test(navigator.userAgent);
        },

        execUserAgent: function(regExp) {
            return regExp.exec(navigator.userAgent);
        },

        /**
         * Fail-safe getter for devicePixelRatio (it is not supported by IE).
         * window.devicePixelRatio is the ratio between physical pixels and device-independent pixels (DIPs) on device.
         * window.devicePixelRatio = physical pixels / dips.
         *
         * As iPhone 6 Plus reports incorrect (rounded) DPR = 3, this method workarounds the problem by calculating
         * real DPR for mentioned device, by dividing its real screen height (1920) to its reported screen.height (736)
         * which gives ~2.6 which should have being reported by this device instead of rounded value. All this is
         * required as later logic will try to find-out real device's screen resolution by taking DPR value and
         * multiplying it to reported screen.width or height (max value is used), so 736 * ~2.6 = 1920. Without this
         * workaround it would be 736 * 3 = 2208.
         *
         * Warning!
         * As there is no normal way to distinguish iPhones, the only possible way was used: to check if
         * window.devicePixelRatio is grater than 2, as all iPhones report it as 2 except iPhone 6 Plus which reports
         * it as 3. If future iPhones will need to have special treatment different from current 6 Plus treatment,
         * and if they will have same User-Agent string and report dpr as 3 - than it will be impossible to distinguish
         * new iPhone from iPhone 6 Plus and thus implement this treatment! God save us all...
         *
         * @returns {number} window.devicePixelRatio if it exists, null otherwise
         */
        getDPR: function() {
            if (window.devicePixelRatio) {
                if (Device.isIphone() && window.devicePixelRatio > 2) { //Workaround for iPhone 6 Plus
                    return Constants.fullHDWidth / Math.max(screen.width, screen.height); //2,608695652173913
                } else {
                    return window.devicePixelRatio;
                }
            } else {
                return null;
            }
        },

        isIphone: function() {
            return Device.testUserAgent(/iPhone/i);
        },

        isIpod: function() {
            return Device.testUserAgent(/iPod/i);
        },

        isIpad: function() {
            return Device.testUserAgent(/iPad/i);
        },

        OS: (function() {
            return {
                isIos: function() {
                    return Device.isIphone() || Device.isIpod() || Device.isIpad();
                },

                isAndroid: function() {
                    return Device.testUserAgent(/Android/i);
                }
            };
        })(),

        Browser: (function() {
            return {
                /**
                 * @returns {boolean} true for Chrome and "new" Android Webkit browser (as there is no clear way how to
                 * distinguish these two), false otherwise.
                 */
                isChrome: function() {
                    return Device.testUserAgent(/(?:Chrome|CriOS|CrMo)/i);
                },

                /**
                 * Such method is required in context of Device.Screen.isHighResolution()
                 *
                 * @returns {boolean} true for Chrome with version less than 25 (not including), false otherwise.
                 */
                isOldChrome: function() {
                    return this.isChrome() && this.Version.getMajor() < Constants.oldChromeVersionThreshold;
                },

                /**
                 * Checks if user agent contains "Android" AND "AppleWebKit" AND NOT "Chrome", ignoring case.
                 *
                 * @returns {boolean} return true only for "old" Android Webkit browser. The "new" one (appeared at
                 * least on Galaxy S4) is now on Chrome engine and so contains word "Chrome" in ua-string.
                 */
                isAndroidWebkit: function() {
                    return Device.testUserAgent(/(?:Android)(?=.+AppleWebKit)(?!.+(?:Chrome|UCBrowser))/i);
                },

                isUCBrowser: function() {
                    return Device.testUserAgent(/UCBrowser/i);
                },

                Version: (function() {
                    /*private*/ function getVersionSafely(array) {
                        if (array) {
                            return array[1];
                        } else {
                            return null;
                        }
                    }

                    return {
                        getRaw: function() {
                            if (Device.Browser.isChrome()) {
                                return getVersionSafely(Device.execUserAgent(/(?:Chrome\/|CriOS\/|CrMo\/)([^\s]*)/i));
                            } else if (Device.Browser.isAndroidWebkit() || Device.OS.isIos()) {
                                return getVersionSafely(Device.execUserAgent(/(?:Version\/)([^\s]*)/i));
                            } else {
                                return null;
                            }
                        },

                        getMajor: function() {
                            if (this.getRaw()) {
                                return this.getRaw().split(".")[0];
                            } else {
                                return null;
                            }
                        }
                    };
                })()
            };
        })(),

        Screen: (function() {
            var resolutions = Constants.mobileDevicesUniqueResolutions; //shortcut

            /**
             * [Private] Converts value to pixels by multiplying it on DPR (Device Pixel Ratio).
             * Makes decision if multiplication is needed. Some browsers report values like screen.width/height
             * in pixels and some in DIPs (Device Independent Pixels). Latest Chrome and Safari report in DIPS,
             * Default Android browser and UCBrowser in pixels. Old Chrome reported in pixels, but somewhere between
             * 19 and 24 version Chrome began to report in DIPs, but unfortunately info about in which exact version
             * this happened is not available to the author of this file. It is confirmed that Chrome 18 reported in px
             * and Chrome 25 in DIPS.
             *
             * @param size adjusted by multiplying on DPR if its Chrome older than 25 or
             * new Default Android browser (on Chrome engine).
             *
             * @returns {number} size in pixels, previously converted from DIPS if it was needed.
             */
            function convertFromDipsToPx(size) {
                if (Device.Browser.isOldChrome() || Device.Browser.isAndroidWebkit() || Device.Browser.isUCBrowser()) {
                    return size;
                } else {
                    return Math.floor(size * Device.getDPR());
                }
            }

            /**
             * [Private] Iterates over set of unique resolutions, divides each by input resolution to receive ratio.
             * If ratio less than 1 - returns previous resolution in the list as closest, meaning that iteration reached
             * the resolution which lower than input one. Relies on the facts that array of resolutions is sorted
             * descending and that browser may return resolution LOWER than device has in fact (not higher).
             *
             * WARNING! This method may work incorrectly if resolutions map will start to contain too much resolutions
             * which close to each other by value.
             *
             * @param inputResolution incorrect resolution returned by the browser
             * @returns {number} closest correct resolution
             */
            function selectClosestResolution(inputResolution) {
                for (var i = 0; i < resolutions.length; i++) {
                    if (resolutions[i] / inputResolution < 1) {
                        return resolutions[i - 1];
                    }
                }

                return resolutions[resolutions.length - 1];
            }

            return {
                getWidth: function() {
                    return convertFromDipsToPx(screen.width);
                },

                getHeight: function() {
                    return convertFromDipsToPx(screen.height);
                },

                /**
                 * Chrome in new version (at least in 27) started to return incorrect values for
                 * screen.width/screen.height properties on devices with navigation bar taking space from the screen
                 * itself. Now these properties are reduced by height of this navigation panel (which can be different
                 * in landscape/portrait modes). This method tries to adjust this by using selectClosestResolution()
                 * method but due to its characteristics it used only on high resolution screens.
                 *
                 * @returns {number} size of wider side of the screen adjusted if its high resolution screen
                 */
                getWiderSideSize: function() {
                    return selectClosestResolution(Math.max(this.getWidth(), this.getHeight()));
                },

                /**
                 * @returns {boolean} true if wider side size is more than threshold (1920px), false otherwise
                 */
                isHighResolution: function() {
                    return this.getWiderSideSize() >= Constants.highResScreenThreshold;
                }
            };
        })()
    };
})();

/**
 * Creates viewport when head section is parsed. Makes decision upon how exactly viewport will be created based on
 * device's screen size and browser.
 */
var ViewportManager = (function() {
    var selectedViewport; //stored value between method calls

    /**
     * [Private] Iterates over Constants.exceptionalDevices and tests each key (which is device regexp)
     * upon navigator.userAgent. Stores viewport content selected from the map and returns true if current device is
     * found in the map.
     * Otherwise stores null and returns false.
     *
     * @returns {boolean} true if device found in the list, false otherwise
     */
    function isDeviceInExceptionalList() {
        for (var deviceKey in Constants.exceptionalDevices) {
            if (Device.testUserAgent(new RegExp(deviceKey, "i"))) {
                selectedViewport = Constants.exceptionalDevices[deviceKey];
                return true;
            }
        }

        selectedViewport = null;
        return false;
    }

    /**
     * @returns {String} stored value for already selected viewport content after isDeviceInExceptionalList() run,
     * if stored value undefined - this method will run isDeviceInExceptionalList() first and then retrieve again.
     */
    function getCorrespondentExceptionalViewPort() {
        if (selectedViewport != undefined) {
            return selectedViewport;
        } else {
            isDeviceInExceptionalList();
            return selectedViewport;
        }
    }

    /**
     * @returns {number} maximum supported resolution according to business requirements
     */
    function getMaxSupportedResolution() {
        if (Device.isIpad()) {
            return Constants.maxIpadSupportedResolution;
        } else {
            return Constants.maxAndroidSupportedResolution;
        }
    }

    return {
        createViewport: function() {
            if (isDeviceInExceptionalList()) {
                Viewport.setViewportExceptionalDevice(getCorrespondentExceptionalViewPort());
            } else if (Device.Browser.isAndroidWebkit()) {
                var targetDpi = Device.Screen.isHighResolution() ? "medium-dpi" : "device-dpi";

                Viewport.setViewportAndroidWebkit(targetDpi);
            } else {
                var factor = Device.Screen.isHighResolution() ?
                    Device.Screen.getWiderSideSize() / getMaxSupportedResolution() : 1;

                Viewport.setViewport(factor/Device.getDPR());
            }
        },

        getScaleValue: function() {
            return Viewport.getViewportValue();
        }
    };
})();

ViewportManager.createViewport();