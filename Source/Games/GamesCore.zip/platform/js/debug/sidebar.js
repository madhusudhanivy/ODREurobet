﻿function PTSideBar(props) {
    var SB = new Object;
    var TSB = new Object;
    TSB.cookieName = "CacheTimestamp";
    TSB.cacheconfig = "platform/cache_delay.cfg";
    if (props) {
        TSB.props = props
    }
    SB.init = function (e, t) {
        var n;
        var r;
        var i;
        var s;
        var o;
        i = document.location.href;
        TSB.onInitCompleteCallback = window.logicInitCompleted;
        if (t == null) {
            t = document.body
        }
        TSB.iframeContainer = t;
        TSB.htcmdQue = [];
        TSB.settings = {};
        TSB.settings.layouts = new Object;
        TSB.settings.language = "en";
        TSB.settings.config = "";
        if (TSB.props) {
            for (r in TSB.props) {
                TSB.settings[r] = TSB.props[r]
            }
            TSB.props = null
        } else {
            if (i.indexOf("?") != 1) {
                s = i.split("?")[1].split("&");
                for (n = 0; n < s.length; n++) {
                    o = s[n].split("=");
                    TSB.settings[o[0]] = decodeURIComponent(o[1])
                }
            } else {
                return
            }
        }
        TSB.settings.language = TSB.settings.language.toLowerCase();
        TSB.settings.config = TSB.attachRequieredTags(TSB.settings.config);
        TSB.settings.config = TSB.replaceTags(TSB.settings.config);
        TSB.loadConfig()
    };
    SB.getGadgets = function (e) {
        if(TSB.settings.layouts[e]) {
            return TSB.settings.layouts[e].gadgets
        } else {
            return null;
        }
    };
    SB.getMaxWidth = function (e) {
        return TSB.settings.layouts[e].maxwidth
    };
    SB.getMaxHeight = function (e) {
        return TSB.settings.layouts[e].maxheight
    };
    SB.getForceOpen = function (e) {
        return TSB.settings.layouts[e].forceopen
    };
    SB.getLanguage = function () {
        return TSB.settings.language
    };
    SB.htcmd = function (e, t) {
        if (TSB.htcmdQue.length == 0) {
            setTimeout(TSB.executeHtcmd, 100)
        }
        if (t != null) {
            e += "&id=" + t
        }
        TSB.htcmdQue.push(e)
    };
    TSB.initDone = function () {
        setTimeout(TSB.doInitDoneCallback, 50)
    };
    TSB.doInitDoneCallback = function () {
        TSB.onInitCompleteCallback();
        TSB.onInitCompleteCallback = null
    };
    TSB.loadConfig = function () {
        var e;
        cache_expiration_delay = null;
        e = document.createElement("script");
        e.id = "SBCacheConfig";
        e.src = TSB.cacheconfig;
        document.head.appendChild(e);
        TSB.testConfig()
    };
    TSB.testConfig = function () {
        if (cache_expiration_delay == null) {
            setTimeout(TSB.testConfig, 50)
        } else {
            TSB.onConfigReady(cache_expiration_delay)
        }
    };
    TSB.onConfigReady = function (e) {
        var t;
        t = document.getElementById("SBCacheConfig");
        document.head.removeChild(t);
        TSB.settings.cache_delay = parseInt(e);
        TSB.syncCookie();
        if (TSB.settings.config.substr(-1) != "&") {
            TSB.settings.config += "&"
        }
        TSB.settings.config += "t=" + TSB.settings.timestamp;
        TSB.loadGadgetConfig()
    };
    TSB.loadGadgetConfig = function () {
        var e;
        response = null;
        e = document.createElement("script");
        e.id = "SBGadgetConfig";
        e.src = TSB.settings.config;
        document.head.appendChild(e);
        TSB.testGadgetConfig()
    };
    TSB.testGadgetConfig = function () {
        if (response == null) {
            setTimeout(TSB.testGadgetConfig, 50)
        } else {
            TSB.onGadgetConfigReady(response)
        }
    };
    TSB.onGadgetConfigReady = function (gadgetstr) {
        var el;
        var t;
        var i;
        var ii;
        var o;
        var gadgets;
        var targets;
        var layouttype;
        el = document.getElementById("SBGadgetConfig");
        document.head.removeChild(el);
        t = eval(gadgetstr);
        if (t.length == 0) {
            return
        }
        for (i = 0; i < t.length; i++) {
            targets = [];
            for (ii = 0; ii < t[i].layouts.length; ii++) {
                for (iii = 0; iii < t[i].layouts[ii].allowed.length; iii++) {
                    layouttype = t[i].layouts[ii].allowed[iii];
                    o = new Object;
                    targets.push(o);
                    if (TSB.settings.layouts[layouttype] == null) {
                        TSB.settings.layouts[layouttype] = new Object;
                        TSB.settings.layouts[layouttype].maxwidth = 0;
                        TSB.settings.layouts[layouttype].maxheight = 0;
                        TSB.settings.layouts[layouttype].forceopen = -1;
                        TSB.settings.layouts[layouttype].gadgets = []
                    }
                    o.width = Number(t[i].layouts[ii].width);
                    o.height = Number(t[i].layouts[ii].height);
                    o.url = TSB.replaceTags(t[i].layouts[ii].url);
                    o.id = TSB.settings.layouts[layouttype].gadgets.length;
                    if (TSB.settings.layouts[layouttype].maxwidth < o.width) {
                        TSB.settings.layouts[layouttype].maxwidth = o.width
                    }
                    if (TSB.settings.layouts[layouttype].maxheight < o.height) {
                        TSB.settings.layouts[layouttype].maxheight = o.height
                    }
                    if (t[i].forceopen == "1" && TSB.settings.layouts[layouttype].forceopen == -1) {
                        TSB.settings.layouts[layouttype].forceopen = o.id
                    }
                    TSB.settings.layouts[layouttype].gadgets.push(o)
                }
            }
            TSB.setPropertyOnList(targets, "code", t[i].code);
            TSB.setPropertyOnList(targets, "name", t[i].name);
            TSB.setPropertyOnList(targets, "israce", t[i].israce == "1");
            TSB.setPropertyOnList(targets, "isopen", t[i].isopened == "1");
            TSB.setPropertyOnList(targets, "isDefaultForAnalytics", t[i].isopened == "1");
            if (o.url != null) {
                if (o.url.indexOf("?") != -1) {
                    o.url += "&"
                } else {
                    o.url += "?"
                }
                o.url += "pt_connection=" + encodeURIComponent(TSB.settings.connection) + "&id=" + i + "&"
            }
        }
        for (layouttype in TSB.settings.layouts) {
            try {
                gadgets = TSB.settings.layouts[layouttype].gadgets;
                if (TSB.settings.layouts[layouttype].forceopen != -1) {
                    TSB.setPropertyOnList(gadgets, "isopen", false);
                    TSB.setPropertyOnList(gadgets, "isDefaultForAnalytics", false);
                    gadgets[TSB.settings.layouts[layouttype]].forceopen = true;
                    gadgets[TSB.settings.layouts[layouttype]].isDefaultForAnalytics = true;
                    TSB.settings.layouts[layouttype].forceopen = true
                } else {
                    for (i = 0; i < gadgets.length; i++) {
                        if (gadgets[i].isopen == true) {
                            TSB.setPropertyOnList(gadgets, "isopen", false);
                            TSB.setPropertyOnList(gadgets, "isDefaultForAnalytics", false);
                            gadgets[i].forceopen = true;
                            gadgets[i].isDefaultForAnalytics = true;
                            break
                        }
                    }
                    TSB.settings.layouts[layouttype].forceopen = false
                }
            } catch(e) {
                console.log(e);
            }
        }
        TSB.initDone()
    };
    TSB.setPropertyOnList = function (e, t, n) {
        var r;
        for (r = 0; r < e.length; r++) {
            e[r][t] = n
        }
    };
    TSB.executeHtcmd = function () {
        var e;
        var t;
        var n;
        t = TSB.htcmdQue.shift();
        n = TSB.htcmdQue.shift();
        e = document.createElement("iframe");
        e.frameborder = 0;
        e.style = "visibility:hidden; position:absolute; top:0px; left:0px;";
        e.style.visibility = "hidden";
        e.style.position = "absolute";
        e.style.top = "0px";
        e.style.left = "0px";
        e.src = TSB.settings.connection + "#" + encodeURIComponent(t);
        if (e.attachEvent) {
            e.attachEvent("onload", TSB.onHtcmdComplete)
        } else {
            e.onload = TSB.onHtcmdComplete
        }
        TSB.iframeContainer.appendChild(e);
        if (TSB.htcmdQue.length > 0) {
            setTimeout(TSB.executeHtcmd, 100)
        }
    };
    TSB.onHtcmdComplete = function (e) {
        var t;
        t = e.target;
        TSB.iframeContainer.removeChild(t)
    };
    TSB.replaceTags = function (e) {
        var t;
        var n;
        var r;
        var i;
        for (var s = 0; s < e.length; s++) {
            t = e.indexOf("[", s);
            if (t == -1) {
                break
            } else {
                n = e.indexOf("]", t);
                if (n == -1) {
                    break
                } else {
                    r = e.substr(t + 1, n - t - 1);
                    i = encodeURIComponent(TSB.tagValue(r));
                    e = e.substr(0, t) + i + e.substr(n + 1)
                }
            }
        }
        return e
    };
    TSB.attachRequieredTags = function (e) {
        var t = "";
        var n = ["casino", "gametypes", "gametype", "username", "clienttype", "clientplatform", "preview", "realmode"];
        var r;
        var i;
        for (i = 0; i < n.length; i++) {
            r = n[i];
            if (TSB.settings[r] != null && e.indexOf("[" + r + "]") == -1) {
                t += r + "=[" + r + "]&"
            }
        }
        if (t != "") {
            if (e.charAt(-1) == "&" || e.charAt(-1) == "?") {
                e += t
            } else if (e.indexOf("?") == -1) {
                e += "?" + t
            } else {
                e += "&" + t
            }
        }
        return e
    };
    TSB.tagValue = function (e) {
        var t = e;
        if (TSB.settings[e] != null) {
            t = TSB.settings[e]
        }
        return t
    };
    TSB.syncCookie = function () {
        var e;
        var t;
        var n;
        var r;
        var i;
        r = 0;
        t = document.cookie.split("; ");
        for (e = 0; e < t.length; e++) {
            n = t[e].split("=");
            if (n[0] == TSB.cookieName) {
                r = parseInt(n[1])
            }
        }
        i = (new Date).getTime();
        if (i - r > TSB.settings.cache_delay) {
            document.cookie = SB.cookieName + "=" + i
        }
        r = i;
        TSB.settings.timestamp = r
    };
    return SB
}