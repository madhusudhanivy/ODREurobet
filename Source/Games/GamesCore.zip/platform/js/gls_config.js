var gls_config = {
    "path": "https://conf.staticconfig.com/location.js",
    "minutesPerGeoLocationRequest": 240
}