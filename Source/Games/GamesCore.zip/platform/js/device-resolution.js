Detect.registerExtension(function(){

    function DeviceResolution(){
        Object.defineProperty(this, "browsers", {
            value: {},
            writable: false
        });
    }


    DeviceResolution.prototype.addBrowser = function(browser){
        this.browsers[browser.getId()] = browser;
    };

    DeviceResolution.prototype.getBrowser = function(id){
        return this.browsers[id];
    };


    function BrowserResolution(browser, landscape, portrait){
        Object.defineProperties(this,{
            "id":{
                value: browser.name,
                writable: false
            },
            "landscape":{
                value: landscape,
                writable: false
            },
            "portrait":{
                value: portrait,
                writable: false
            }
        })
    }

    BrowserResolution.prototype.getId = function(){
        return this.id;
    };

    BrowserResolution.prototype.getLandscape = function(){
        return this.landscape;
    };

    BrowserResolution.prototype.getPortrait = function(){
        return this.portrait;
    };

    function DeviceTargetSize(core1, core2){
        Object.defineProperties(this, {
            "core1":{
                value: core1,
                writable: false
            },
            "core2":{
                value: core2,
                writable: false
            }
        })
    }

    DeviceTargetSize.prototype.getCore1 = function(){
        return this.core1;
    };

    DeviceTargetSize.prototype.getCore2 = function(){
        return this.core2;
    };

    return {
        init: function () {
            //Iphones

            //Iphone 5
            Detect.D.Iphone5.deviceResolution = new DeviceResolution();
            Detect.D.Iphone5.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Safari, [568, 320], [320, 529]));
            Detect.D.Iphone5.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [568, 300], [320, 548]));
            Detect.D.Iphone5.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [568, 300], [320, 568]));

            //Iphone 6
            Detect.D.Iphone6.deviceResolution = new DeviceResolution();
            Detect.D.Iphone6.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Safari, [667, 375], [375, 628]));
            Detect.D.Iphone6.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [667, 355], [375, 647]));
            Detect.D.Iphone6.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [667, 355], [375, 647]));

            //Iphone 6Plus
            Detect.D.Iphone6Plus.deviceResolution = new DeviceResolution();
            Detect.D.Iphone6Plus.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Safari, [736, 414], [414, 696]));
            Detect.D.Iphone6Plus.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [736, 394], [414, 716]));
            Detect.D.Iphone6Plus.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [736, 395], [414, 716]));


            //Ipads
            Detect.D.Ipad.deviceResolution = new DeviceResolution();
            Detect.D.Ipad.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Safari, [1024, 729], [768, 985]));
            Detect.D.Ipad.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [1024, 748], [768, 1004]));
            Detect.D.Ipad.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1024, 671], [640, 927]));
            Detect.D.Ipad.targetSize = new DeviceTargetSize([1000, 750], [1280, 600]);

            //Ipads
            Detect.D.IpadRetina.deviceResolution = new DeviceResolution();
            Detect.D.IpadRetina.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Safari, [1024, 729], [768, 985]));
            Detect.D.IpadRetina.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [1024, 748], [768, 1004]));
            Detect.D.IpadRetina.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1024, 671], [640, 927]));
            Detect.D.IpadRetina.targetSize = new DeviceTargetSize([1000, 750], [1280, 600]);

            //Ipads
            Detect.D.IpadPro129.deviceResolution = new DeviceResolution();
            Detect.D.IpadPro129.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Safari, [1366, 985], [1024, 1327]));
            Detect.D.IpadPro129.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [1024, 748], [768, 1004]));
            Detect.D.IpadPro129.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1366, 988], [1004, 1366]));
            Detect.D.IpadPro129.targetSize = new DeviceTargetSize([1000, 750], [1280, 600]);



            //Samsung

            //Samsung S7
            Detect.D.GalaxyS7.deviceResolution = new DeviceResolution();
            Detect.D.GalaxyS7.deviceResolution.addBrowser(new BrowserResolution(Detect.B.SamsungBrowser, [640, 336], [360, 616]));
            Detect.D.GalaxyS7.deviceResolution.addBrowser(new BrowserResolution(Detect.B.AndroidWebkit, [640, 336], [360, 616]));
            Detect.D.GalaxyS7.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [640, 336], [360, 616]));
            Detect.D.GalaxyS7.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [2560, 1344], [1440, 2272]));


            //Samsung S6Edge
            Detect.D.GalaxyS6Edge.deviceResolution = new DeviceResolution();
            Detect.D.GalaxyS6Edge.deviceResolution.addBrowser(new BrowserResolution(Detect.B.SamsungBrowser, [640, 360], [360, 616]));
            Detect.D.GalaxyS6Edge.deviceResolution.addBrowser(new BrowserResolution(Detect.B.AndroidWebkit, [640, 336], [360, 616]));
            Detect.D.GalaxyS6Edge.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [640, 336], [360, 616]));
            Detect.D.GalaxyS6Edge.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [2560, 1344], [1440, 2272]));

            //Samsung S6
            Detect.D.GalaxyS6.deviceResolution = new DeviceResolution();
            Detect.D.GalaxyS6.deviceResolution.addBrowser(new BrowserResolution(Detect.B.SamsungBrowser, [640, 360], [360, 616]));
            Detect.D.GalaxyS6.deviceResolution.addBrowser(new BrowserResolution(Detect.B.AndroidWebkit, [640, 336], [360, 616]));
            Detect.D.GalaxyS6.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [640, 336], [360, 616]));
            Detect.D.GalaxyS6.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [2560, 1344], [1440, 2272]));


            //Samsung S5
            Detect.D.GalaxyS5.deviceResolution = new DeviceResolution();
            Detect.D.GalaxyS5.deviceResolution.addBrowser(new BrowserResolution(Detect.B.SamsungBrowser, [640, 335], [360, 615]));
            Detect.D.GalaxyS5.deviceResolution.addBrowser(new BrowserResolution(Detect.B.AndroidWebkit, [640, 335], [360, 615]));
            Detect.D.GalaxyS5.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [640, 335], [360, 615]));
            Detect.D.GalaxyS5.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1920, 1005], [1080, 1701]));

            //Samsung S4
            Detect.D.GalaxyS4.deviceResolution = new DeviceResolution();
            Detect.D.GalaxyS4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.SamsungBrowser, [640, 335], [360, 615]));
            Detect.D.GalaxyS4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.AndroidWebkit, [640, 335], [360, 615]));
            Detect.D.GalaxyS4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [640, 335], [360, 615]));
            Detect.D.GalaxyS4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1920, 1005], [1080, 1701]));


            //Samsung Note4
            Detect.D.GalaxyNote4.deviceResolution = new DeviceResolution();
            Detect.D.GalaxyNote4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.SamsungBrowser, [640, 336], [360, 616]));
            Detect.D.GalaxyNote4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.AndroidWebkit, [640, 336], [360, 616]));
            Detect.D.GalaxyNote4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [640, 336], [360, 616]));
            Detect.D.GalaxyNote4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [2560, 1344], [1440, 2272]));

            //LG G4
            Detect.D.LGG4.deviceResolution = new DeviceResolution();
            Detect.D.LGG4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.AndroidWebkit, [598, 336], [360, 574]));
            Detect.D.LGG4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [598, 336], [360, 574]));
            Detect.D.LGG4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [2392, 1344], [1440, 2392]));
            Detect.D.LGG4.targetSize = new DeviceTargetSize([980, 560], [1280, 600]);

            //LG G5    
            Detect.D.LGG5.deviceResolution = new DeviceResolution();
            Detect.D.LGG5.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [598, 336], [360, 620]));
            Detect.D.LGG5.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [2392, 1344], [1440, 2392]));

            //Xiaomi

            //Xiaomi Mi4
            Detect.D.XiaomiMi4.deviceResolution = new DeviceResolution();
            Detect.D.XiaomiMi4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [640, 340], [360, 574]));
            Detect.D.XiaomiMi4.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1920, 1020], [1080, 1716]));

            //Xiaomi Mi3
            Detect.D.XiaomiMi3.deviceResolution = new DeviceResolution();
            Detect.D.XiaomiMi3.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [640, 340], [360, 574]));
            Detect.D.XiaomiMi3.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1920, 1020], [1080, 1716]));


            //Nexus
            //Nexus 6p
            Detect.D.Nexus6P.deviceResolution = new DeviceResolution();
            Detect.D.Nexus6P.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [684, 388], [412, 660]));
            Detect.D.Nexus6P.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [2392, 1356], [1440, 2140]));

            //Nexus 5.x
            Detect.D.Nexus5X.deviceResolution = new DeviceResolution();
            Detect.D.Nexus5X.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [684, 388], [412, 660]));
            Detect.D.Nexus5X.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1794, 1017], [1080, 1605]));

            //Nexus 7
            Detect.D.Nexus7.deviceResolution = new DeviceResolution();
            Detect.D.Nexus7.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [960, 527], [600, 887]));
            Detect.D.Nexus7.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1920, 1054], [1200, 1678]));

            //Lenovo

            //LenovoA889
            Detect.D.LenovoA889.deviceResolution = new DeviceResolution();
            Detect.D.LenovoA889.deviceResolution.addBrowser(new BrowserResolution(Detect.B.AndroidWebkit, [897, 502], [540, 850]));
            Detect.D.LenovoA889.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [598, 335], [360, 567]));
            Detect.D.LenovoA889.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [897, 540], [540, 888]));

            //LenovoA889
            Detect.D.LenovoTab2A730HC.deviceResolution = new DeviceResolution();
            Detect.D.LenovoTab2A730HC.deviceResolution.addBrowser(new BrowserResolution(Detect.B.Chrome, [1024, 527], [600, 951]));
            Detect.D.LenovoTab2A730HC.deviceResolution.addBrowser(new BrowserResolution(Detect.B.UcBrowser, [1024, 527], [600, 976]));




        }
    }

}());