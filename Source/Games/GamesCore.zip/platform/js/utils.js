var CP = {
    Utils: {},
    Log: {},
    Scale: {},
    Debug: {}
};
(function (root) {

    var core1 = ["hlk","hlk2","hulk", "ba","baws","bj_mh5","cheaa","evj","ges","glrj","gos", "hf", "ir", "ir2", "irmn3", "pgv", "pnp", "ro_g", "ssp", "spidc", "avng"];

    var urlParams = {};
    var queryStringPairs = window.location.search.substr(1).split("&");
    for(var i = 0; i < queryStringPairs.length; i++){
        var keyValue = queryStringPairs[i].split("=");
        var key = keyValue[0];
        var keylower = keyValue[0].toLowerCase();
        var val = keyValue[1] ? keyValue[1] : null;
        urlParams[key] = val;
        urlParams[keylower] = val;

    }

    root.debounce = function (func, wait, immediate) {

        var timeout = null;

        return function () {

            var context = this;
            var args = arguments;

            var callNow = immediate && !timeout;

            timeout = setTimeout(function(){
                clearTimeout(timeout);
                if(!immediate){
                    func.apply(context, args);
                }
            }, wait || 200);

            if(callNow){
                func.apply(context, args);
            }

        }
    };

    root.isCore1Game = function(code){
        return core1.indexOf(code) !== -1;
    };

    root.getParam = function(code, casesensetive){
        var c = casesensetive ? code : code.toLowerCase();
        return urlParams[c];
    };

    root.inJsViewport = function() {
        try {
            return !!window.top.ScalingReport;
        } catch (e) {
            return false;
        }
    };

    root.isTopFrame = function(){
        return window.top === window.self;
    };

    root.getPathToMobileLauncher = function(){
        var link = document.createElement("a");
        link.href = "../../casinoclient.html";
        return link.href;
    };

})(CP.Utils);

(function(root) {
    var config = {};
    var forceEnabled = false;

    // API
    root.enable = function () {
        forceEnabled = true;
        dispatchLogEvent(forceEnabled);
    };

    root.disable = function () {
        forceEnabled = false;
        dispatchLogEvent(forceEnabled);
    };

    root.setCfg = function (cfg) {
        config = cfg;
    };

    root.config = function () {
        console.dir(config);
    };

    root.isForceEnabled = function () {
        return forceEnabled;
    };

    function dispatchLogEvent(isEnabled) {
        dispatchEvent(new CustomEvent('cpLogStateEvent', { 'detail': isEnabled }));
    }
}(CP.Log));

(function(root) {
    root.enable = function(code) {
        var d = new Date();
        var debugCode = (d.getDay() + d.getDate() + d.getMonth() + 1) * d.getFullYear();
        if (debugCode === code) {
            dispatchEvent(new CustomEvent('cpEnableDebugPanel', { 'detail': true }));
        }
    };

    root.disable = function() {
        dispatchEvent(new CustomEvent('cpEnableDebugPanel', { 'detail': false }));
    };

}(CP.Debug));

(function (root) {
    var MIN_SCALED_SIDE = 600,
        MAX_SCALED_SIDE = 830,
        MOBILE_IDEAL_SIDE = 750;

    var scale = 1;
    var dpr = 1;
    var sizes = {
        width: 0,
        height: 0
    };
    var isSafariBrowser = false;
    var isSamsungBrowser = false;
    var isOperaBrowser = false;
    var isChromeBrowser = false;
    var cssScalingMode = true;
    var cssVariablesSupported = true;

    var updateStyles = function(){};

    root.activateJsScaling = function () {
        cssScalingMode = false;
        activate();
    };

    root.activateCSSScaling = function () {
        dpr = detectDPR();
        cssVariablesSupported = window.CSS && window.CSS.supports && window.CSS.supports("(height:var(--value))");
        // once set scale index
        setScaleIndex();
        activate();
    };

    function activate() {
        isSafariBrowser = detectSafari();
        isOperaBrowser = detectOpera();
        isSamsungBrowser = detectSamsung();
        isChromeBrowser = detectChrome();
        setUpdateStylesFunction();
        // set initial values
        onResizeEvent();

        window.addEventListener("resize", onResizeEvent);

        // re-check conditions every 3 seconds
        setInterval(function() {
            onResizeEvent();
        }, 3000);
    }

    function detectSafari() {
        var userAgent = navigator.userAgent.toLowerCase();
        return (userAgent.indexOf("ipad") !== -1 || userAgent.indexOf("iphone") !== -1
            || userAgent.indexOf("ipod") !== -1) && userAgent.indexOf("safari") !== -1
            && userAgent.indexOf("crios") === -1;
    }

    function detectChrome() {
        var userAgent = navigator.userAgent.toLowerCase();
        return userAgent.search(/(?:Chrome|CriOS|CrMo)(?!.+(?:Edge|UCBrowser))/i) !== -1;
    }

     function detectOpera() {
        var userAgent = navigator.userAgent.toLowerCase();
        return userAgent.search(/OPR/i) !== -1;
    }

    function detectSamsung() {
        var userAgent = navigator.userAgent.toLowerCase();
        return userAgent.search(/SamsungBrowser/i) !== -1;
    }

    function detectAppleDevice() {
        var userAgent = navigator.userAgent.toLowerCase();
        return (userAgent.indexOf("iphone") !== -1 || userAgent.indexOf("ipad") !== -1
            || userAgent.indexOf("ipod") !== -1);
    }

    function detectDPR() {
        var dpr = window.devicePixelRatio ? window.devicePixelRatio : 1;
        if (dpr > 2) {
            return 2;
        }
        return dpr;
    }

    function onResizeEvent() {
        if (isKeyboardResize()) {
            //ignore all resize events from keyboard
            return;
        }
        var newSizes = getWindowSizes();
        // check
        if (needUpdate(newSizes) || (cssScalingMode && !cssVariablesSupported && needUpdate(getActualSizes(newSizes)))) {
            sizes = newSizes;
            updateStyles(sizes);
        }
    }

    function setUpdateStylesFunction() {
        // Then we set the value in the --vh custom property to the root of the document
        //document.documentElement.style.setProperty('--vh', sizes.height * 0.01 +'px');
        //document.documentElement.style.setProperty('--vw', sizes.width * 0.01 +'px');
        if (cssScalingMode) {
            if (cssVariablesSupported) {
                updateStyles = function(sizes) {
                    document.documentElement.style.setProperty('--platform-inner-height', sizes.height + 'px');
                    document.documentElement.style.setProperty('--platform-inner-width', sizes.width + 'px');
                    //calculate
                    document.documentElement.style.setProperty('--platform-scaled-height', scale * sizes.height +'px');
                    document.documentElement.style.setProperty('--platform-scaled-width', scale * sizes.width +'px');
                    document.documentElement.dispatchEvent(new window.CustomEvent('cssScalingAppliedEvent'));
                }
            } else {
                updateStyles = function (sizes) {
                    var style = document.getElementById("css-viewport");
                    var styleAlreadyAppended = true;
                    if(!style){
                        styleAlreadyAppended = false;
                        style = document.createElement("style");
                        style.setAttribute('type', 'text/css');
                        style.id = "css-viewport";
                    }

                    style.innerHTML = generateCss(sizes);

                    var head = document.getElementsByTagName('head')[0];
                    if (head && !styleAlreadyAppended) {
                        head.appendChild(style);
                    }
                    document.documentElement.dispatchEvent(new window.CustomEvent('cssScalingAppliedEvent'));
                }
            }
        } else {
            updateStyles = function(sizes) {
                document.documentElement.style.setProperty('--platform-inner-height', sizes.height + 'px');
                document.documentElement.style.setProperty('--platform-inner-width', sizes.width + 'px');
                document.documentElement.dispatchEvent(new window.CustomEvent('cssScalingAppliedEvent'));
            }
        }
    }

    function isKeyboardResize() {
        return document.body.classList.contains('keyboardVisible');
    }

    function needUpdate(newSizes) {
        if (newSizes.height === sizes.height && newSizes.width === sizes.width) {
            return false;
        }
        return true;
    }

    function ifExceptDevice() {
        var maxSide = Math.max(screen.height, screen.width);
        if (detectAppleDevice() && (maxSide === 812 || maxSide === 896 || maxSide === 736)) {  // Iphone X,XS,XS Max,6-7-8 plus.
            return true;
        }
        return false;
    }

    function setScaleIndex() {
        if (ifExceptDevice()) {
            //quick fix for iPhone X
            scale = 1.5;
        } else {
            var screenMinSide = Math.min(screen.height, screen.width);

            if (isNeedsScaleUp(screenMinSide)) {
                // check dpr scaling result
                if (dpr > 1) {
                    var resultDprHeight = dpr * screenMinSide;
                    if (isCorrectScaledSide(resultDprHeight)) {
                        //if potential result of DPR scaling is correct
                        scale = dpr;
                    }
                } else {
                    //else use calculated coefficient
                    scale = roundToDec(MOBILE_IDEAL_SIDE / screenMinSide);
                }
            }
        }

        document.documentElement.style.setProperty('--platform-css-scale', roundToDec(1/scale));
    }

    function roundToDec(num) {
        return Math.round(num * 100) / 100;
    }

    function isCorrectScaledSide(height) {
        return ( height > MIN_SCALED_SIDE && height < MAX_SCALED_SIDE);
    }

    function isNeedsScaleUp(height) {
        return height < MIN_SCALED_SIDE
    }

    function getWindowSizes() {
        if ( !isBrokenInnerParams() && (inIFrame() || window.visualViewport || isSafariBrowser || isChromeBrowser)) {
            // return window.inner values when inside iFrame
            // return window.inner values if visualViewport property is available
            // return window.inner values if loaded in iOS Safari
            return function () {
                return {
                    width: window.innerWidth,
                    height: window.innerHeight
                }
            }();
        } else {
            return function () {
                return {
                    width: document.body.clientWidth,
                    height: document.body.clientHeight
                }
            }();
        }
    }

    function isBrokenInnerParams() {
        return isOperaBrowser || isSamsungBrowser;
    }

    function inIFrame () {
        try {
            return window.self !== window.top;
        } catch (e) {
            return true;
        }
    }

    var getActualSizes = function(sizes) {
        var max = Math.max(sizes.width, sizes.height);
        var min = Math.min(sizes.width, sizes.height);
        var isLandscape = window.matchMedia("(orientation: landscape)").matches;
        return isLandscape ? {width: max, height: min} : {width: min, height: max};
    };

    var generateCss = function(sizes){
        var scaledWidth = sizes.width * scale;
        var scaledHeight = sizes.height * scale;
        var innerWidth = sizes.width;
        var innerHeight = sizes.height;

        var scaleCssText = "\
            .css-scaling #viewport {\
                width:{scaledWidth}px;\
                height:{scaledHeight}px;\
                min-width:{scaledWidth}px;\
                min-height:{scaledHeight}px;\
                -webkit-transform: scale({scale});\
                -webkit-transform-origin: left top;\
                -ms-transform: scale({scale});\
                -ms-transform-origin: left top;\
                transform: scale({scale});\
                transform-origin: left top;\
            }\
            .gameFrame {\
                min-width: {innerWidth}px;\
                min-height: {innerHeight}px;\
            }\
            #app, #wrapper {\
                width: {innerWidth}px;\
                height: {innerHeight}px;\
            }\
            ";

        scaleCssText = scaleCssText.replace(/\{scale\}/g, 1 / scale);
        scaleCssText = scaleCssText.replace(/\{scaledWidth\}/g, scaledWidth);
        scaleCssText = scaleCssText.replace(/\{scaledHeight\}/g, scaledHeight);
        scaleCssText = scaleCssText.replace(/\{innerWidth\}/g, innerWidth);
        scaleCssText = scaleCssText.replace(/\{innerHeight\}/g, innerHeight);
        return scaleCssText;
    }
})(CP.Scale);
