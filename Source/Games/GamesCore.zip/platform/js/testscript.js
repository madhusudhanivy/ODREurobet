var playtechLocationData = {}
