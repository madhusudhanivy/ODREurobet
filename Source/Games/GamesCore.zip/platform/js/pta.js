var pta = (function() {
    //Cookies.js
    (function(g,f){"use strict";var h=function(e){if("object"!==typeof e.document)throw Error("Cookies.js requires a `window` with a `document` object");var b=function(a,d,c){return 1===arguments.length?b.get(a):b.set(a,d,c)};b._document=e.document;b._cacheKeyPrefix="cookey.";b._maxExpireDate=new Date("Fri, 31 Dec 9999 23:59:59 UTC");b.defaults={path:"/",secure:!1};b.get=function(a){b._cachedDocumentCookie!==b._document.cookie&&b._renewCache();return b._cache[b._cacheKeyPrefix+a]};b.set=function(a,d,c){c=b._getExtendedOptions(c); c.expires=b._getExpiresDate(d===f?-1:c.expires);b._document.cookie=b._generateCookieString(a,d,c);return b};b.expire=function(a,d){return b.set(a,f,d)};b._getExtendedOptions=function(a){return{path:a&&a.path||b.defaults.path,domain:a&&a.domain||b.defaults.domain,expires:a&&a.expires||b.defaults.expires,secure:a&&a.secure!==f?a.secure:b.defaults.secure}};b._isValidDate=function(a){return"[object Date]"===Object.prototype.toString.call(a)&&!isNaN(a.getTime())};b._getExpiresDate=function(a,d){d=d||new Date; "number"===typeof a?a=Infinity===a?b._maxExpireDate:new Date(d.getTime()+1E3*a):"string"===typeof a&&(a=new Date(a));if(a&&!b._isValidDate(a))throw Error("`expires` parameter cannot be converted to a valid Date instance");return a};b._generateCookieString=function(a,b,c){a=a.replace(/[^#$&+\^`|]/g,encodeURIComponent);a=a.replace(/\(/g,"%28").replace(/\)/g,"%29");b=(b+"").replace(/[^!#$&-+\--:<-\[\]-~]/g,encodeURIComponent);c=c||{};a=a+"="+b+(c.path?";path="+c.path:"");a+=c.domain?";domain="+c.domain: "";a+=c.expires?";expires="+c.expires.toUTCString():"";return a+=c.secure?";secure":""};b._getCacheFromString=function(a){var d={};a=a?a.split("; "):[];for(var c=0;c<a.length;c++){var e=b._getKeyValuePairFromCookieString(a[c]);d[b._cacheKeyPrefix+e.key]===f&&(d[b._cacheKeyPrefix+e.key]=e.value)}return d};b._getKeyValuePairFromCookieString=function(a){try {var b = a.indexOf("="),b=0>b?a.length:b;return{key:decodeURIComponent(a.substr(0,b)),value:decodeURIComponent(a.substr(b+1))}} catch (e) {console.warn("Wrong cookie was found:"+a);return{key:"",value:""};}};b._renewCache=function(){b._cache= b._getCacheFromString(b._document.cookie);b._cachedDocumentCookie=b._document.cookie};b._areEnabled=function(){var a="1"===b.set("cookies.js",1).get("cookies.js");b.expire("cookies.js");return a};b.enabled=b._areEnabled();return b},e="object"===typeof g.document?h(g):h;"function"===typeof define&&define.amd?define(function(){return e}):"object"===typeof exports?("object"===typeof module&&"object"===typeof module.exports&&(exports=module.exports=e),exports.Cookies=e):g.Cookies=e})("undefined"===typeof window? this:window);

    var params = {};
    var statsUrl = "";
    var queryStr = "";
    var allowedNames = ["user", "brand", "ctype", "cplat", "skin", "mode", "lang"];
    var day = 60 * 60 * 24;

    var showDebugError = function(err) {
        if (pta.debug === true) {
            alert("pta runtime error: " + err);
        }
    };

    var addToQueryString = function(key,val) {
        try {
            if (queryStr !== "") {
                queryStr += "&";
            }
            queryStr += key + "=" + val;
            return;
        } catch (e) { showDebugError(e); }
    };

    var initQueryString = function() {
        try {
            queryStr = "";
            for (var param in params) {
                if (!params.hasOwnProperty(param)) continue;
                if (queryStr !== "") {
                    queryStr += "&";
                }
                queryStr += param + "=" + params[param];
            }
            return;
        } catch(e) { showDebugError(e); }
    };

    var contains = function(arr, value) {
        try {
            for (var i=0; i<arr.length; i++) {
                if (arr[i] === value) {
                    return true;
                }
            }
            return false;
        } catch(e) { showDebugError(e); }
    };

    var setCust = function(index, name, value) {
        try {
            if ((parseInt(index) < 1) || (parseInt(index) > 5)) {
                showDebugError("set custom field error : <index>=" + index + " is not a valid parameter");
                return false;
            }
            if (typeof name !== 'string') {
                showDebugError("set custom field error: <name>=" + name + " is not a valid parameter");
                return false;
            }
            if (typeof value !== 'string') {
                showDebugError("set custom field error: <value>=" + value + " is not a valid parameter");
                return false;
            }
            var oldCustName = params["custname" + index];
            var oldCustVal = params["custval" + index];
            params["custname" + index] = name;
            params["custval" + index] = value;
            Cookies("custname"+ index, name, { expires: day });
            Cookies("custval"+ index, value, { expires: day });
            if (typeof oldCustName === 'undefined' || typeof oldCustVal === 'undefined') {
                addToQueryString("custname" + index, name);
                addToQueryString("custval" + index, value);
            }
            else if ((name !== oldCustName) || (value !== oldCustVal)) {
                initQueryString();
            }
            return true;
        } catch(e) { showDebugError(e); }
    };

    var setOther = function(param, value) {
        try {
            param = param.toLowerCase();
            if (!contains(allowedNames, param)) {
                showDebugError("set field error: <field>=" + param + " is not a valid parameter");
                return false;
            }
            if (typeof value !== "string") {
                showDebugError("set field error: <value>=" + value + " is not a valid parameter");
                return false;
            }
            var oldValue = params[param];
            params[param] = value;
            Cookies(param, value, { expires: day });
            if (typeof oldValue === 'undefined') {
                addToQueryString(param, value);
            }
            else if (value !== oldValue) {
                initQueryString();
            }
            return true;
        } catch(e) { showDebugError(e); }
    };

    var sendStats = function(category, evnt, label, value) {
        try {
            if (typeof params.user === 'undefined') {
                showDebugError("send error: \"user\" field is mandatory. use \"set\" to add this field");
                return false;
            }
            if (typeof params.brand === 'undefined') {
                showDebugError("send error: \"brand\" field is mandatory. use \"set\" to add this field");
                return false;
            }
            if (typeof params.ctype === 'undefined') {
                showDebugError("send error: \"ctype\" field is mandatory. use \"set\" to add this field");
                return false;
            }
            if (typeof params.cplat === 'undefined') {
                showDebugError("send error: \"cplat\" field is mandatory. use \"set\" to add this field");
                return false;
            }
            if (typeof params.mode === 'undefined') {
                showDebugError("send error: \"mode\" field is mandatory. use \"set\" to add this field");
                return false;
            }
            if (typeof category !== 'string') {
                showDebugError("send error: <category>=" + category + " is not a valid parameter");
                return false;
            }
            if (typeof evnt !== 'string') {
                showDebugError("send error: <action>=" + evnt + " is not a valid parameter");
                return false;
            }
            if (typeof label !== 'string') {
                showDebugError("send error: <label>=" + label + " is not a valid parameter");
                return false;
            }
            if ((value !== null) && (typeof value !== 'undefined') && (typeof value !== 'number')) {
                showDebugError("send error: <value>=" + value + " is not a valid parameter");
                return false;
            }

            var qStr = queryStr +
                "&category=" + category +
                "&event=" + evnt +
                "&label=" + label +
                "&r=" + (new Date()).getTime();
            if ((typeof value !== 'undefined') && (value !== null)) {
                qStr += "&value=" + value;
            }

            window.ptImg = new Image();
            window.ptImg.src = statsUrl + '?' + qStr;
            if(window.ptaDebugOn || document.location.search.indexOf('ptaDebugOn') != -1){
                console.log("$$$$ PTAnalytics: " + statsUrl + qStr);
                //alert(statsUrl + qStr)
            }
            return true;
        } catch(e) { showDebugError(e); }
    };

    var innerPta = function() {
        try {
            for (var i=0; i<arguments.length; i++) {
                var curArg = arguments[i];
                var methodName = curArg[0];
                if (methodName === "set") {
                    var setType = curArg[1];
                    if (setType.toLowerCase() === "cust") {
                        setCust(curArg[2], curArg[3], curArg[4]);
                    }
                    else if (setType.toLowerCase() === "statsurl") {
                        statsUrl = curArg[2];
                    }
                    else {
                        setOther(curArg[1], curArg[2]);
                    }
                }
                else if (methodName === "send") {
                    sendStats(curArg[1], curArg[2], curArg[3], curArg[4]);
                }
                else {
                    showDebugError("method <" + methodName + "> is not supported. use only \"set\" or \"send\"");
                }
            }
        } catch(e) { showDebugError(e); }
    };

    var init = function() {
        try {
            var keys = ["custname1", "custval1", "custname2", "custval2", "custname3", "custval3", "custname4", "custval4", "custname5", "custval5", "user", "brand", "ctype", "cplat", "skin", "mode", "lang"];
            for (var i=0; i<keys.length; i++) {
                var val = Cookies(keys[i]);
                if (typeof val !== 'undefined') {
                    params[keys[i]] = val;
                }
            }
            initQueryString();
        } catch(e) { showDebugError(e); }
    }();

    return innerPta;
})();