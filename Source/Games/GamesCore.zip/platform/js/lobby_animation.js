/**
 * Created by volodymyrv on 4/15/2016.
 */
function shiftLobbyElementsAround(elem){
    var elemsLeft = getLeftLobbyElements(elem);
    var elemsRight = getRightLobbyElements(elem);
    for(i = 0; i < elemsLeft.length; i++){
        elemsLeft[i].className +=" moveLeft";
    }
    for(i = 0; i < elemsRight.length; i++){
        elemsRight[i].className +=" moveRight";
    }
}

function getRightLobbyElements(curElem){
    return getLobbyElementsByDirection(curElem, true);
}

function getLeftLobbyElements(curElem){
    return getLobbyElementsByDirection(curElem, false);
}

function getLobbyElementsByDirection(curElem, right){
    var result = [];
    var currentElem = curElem;
    while(currentElem){
        var elem = right ? currentElem.nextSibling : currentElem.previousSibling;
        if(elem && elem.className && elem.className.indexOf("item") > -1){
            result.push(elem);
        }
        currentElem = elem;
    }
    return result;
}