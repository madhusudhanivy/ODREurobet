var browsers
var templateContent
var unsupportedTemplateButtons
var unsupportedTemplate
var content
var link
var linkEls
var i
var isIE6Or7 = false

browsers = {
	'Chrome': {
		url: 'http://www.google.com/chrome',
		urlAppStore: 'https://itunes.apple.com/us/app/chrome-web-browser-by-google/id535886823?mt=8',
		urlPlayStore: 'https://play.google.com/store/apps/details?id=com.android.chrome&hl=en',
		translationString: 'browserwarning_browser_chrome'
	},
	'Safari': {
		url: 'http://www.apple.com/safari/',
		translationString: 'browserwarning_browser_safari'
	},
	'Firefox': {
		url: 'http://www.firefox.com/',
		translationString: 'browserwarning_browser_firefox'
	},
	'Explorer': {
		url: 'http://windows.microsoft.com/ie',
		translationString: 'browserwarning_browser_ie'
	},
	'Mobile-Safari': {
		translationString: 'browserwarning_browser_mobilesafari'
	}
}

if (!document.getElementsByClassName) {
	document.getElementsByClassName = function(search) {
		var d = document
		var elements
		var pattern
		var i
		var results = []

		if (d.querySelectorAll) { // IE8
			return d.querySelectorAll('.' + search)
		}

		if (d.evaluate) { // IE6, IE7
			pattern = './/*[contains(concat(\' \', @class, \' \'), \' ' + search + ' \')]'
			elements = d.evaluate(pattern, d, null, 0, null)
			while ((i = elements.iterateNext())) {
				results.push(i)
			}
		} else {
			elements = d.getElementsByTagName('*')
			pattern = new RegExp('(^|\\s)' + search + '(\\s|$)')
			for (i = 0; i < elements.length; i++) {
				if (pattern.test(elements[i].className)) {
					results.push(elements[i])
				}
			}
		}
		return results
	}
}

if (GLU.browser.name() == 'Explorer' && (GLU.browser.version() == '6' || GLU.browser.version() == '7')) {
	isIE6Or7 = true
}

function validateBrowser(name, version, returnName) {
	if (GLU.browser.name() != name) {
		return false
	}

	if (GLU.browser.version() < version) {
		return false
	}

	if (returnName) {
		return GLU.browser.name()
	}

	return true
}

function currentUnsupportedSituation() {

	if (GLU.os.is('Mac') && !(validateBrowser('Chrome', 25) || validateBrowser('Safari', 6) || validateBrowser('Firefox', 19))) { // is Mac and not Chrome 25, Safari 6 and Firefox 19
		return {
			type: 'd_apple',
			desc: 'browserwarning_desktop_apple_text',
			browsers: ['Chrome', 'Safari', 'Firefox'],
			upgrade: validateBrowser('Chrome', 25, true) || validateBrowser('Safari', 6, true) || validateBrowser('Firefox', 19, true)
		}
	} else if (GLU.os.is('Windows') && !(validateBrowser('Chrome', 25) || validateBrowser('Firefox', 19) || validateBrowser('Explorer', 10))) {// is Windows and not Chrome 25, Firefox 19 and Explorer 10
		return {
			type: 'd_windows',
			desc: 'browserwarning_desktop_windows_text',
			browsers: ['Chrome', 'Explorer', 'Firefox'],
			upgrade: validateBrowser('Chrome', 25, true) || validateBrowser('Firefox', 19, true) || validateBrowser('Explorer', 10, true)
		}
	} else if (!GLU.device.isTouchOnly()) { // for all the other Desktop situations
		if (GLU.os.is('Mac')) {
			return {
				type: 'd_unknown',
				desc: 'browserwarning_desktop_apple_text',
				browsers: ['Chrome', 'Safari', 'Firefox']
			}
		} else if (GLU.os.is('Windows')) {
			return {
				type: 'd_unknown',
				desc: 'browserwarning_desktop_windows_text',
				browsers: ['Chrome', 'Explorer', 'Firefox']
			}
		}

		return {
			type: 'd_unknown',
			desc: 'browserwarning_desktop_unknown_text',
			browsers: ['Chrome', 'Safari', 'Explorer', 'Firefox']
		}
	} else if (GLU.device.isTouchOnly() && GLU.os.is('Windows') && !validateBrowser('Explorer', 10)) {// is Mobile, Windows and not Explorer 10
		return {
			type: 'm_windows',
			desc: 'browserwarning_mobile_windows_text',
			browsers: [ 'Explorer' ],
			installed: 'Explorer'
		}
	} else if (GLU.device.isTouchOnly() && GLU.os.is('iOS') && GLU.os.version() < 6) {// is Mobile, iOS and version < 6
		return {
			type: 'm_apple_old',
			desc: 'browserwarning_mobile_apple_version_text',
			browsers: [],
			osVersion: '6.0'
		}
	} else if (GLU.device.isTouchOnly() && GLU.os.is('iOS') && (validateBrowser('Safari', 6) || validateBrowser('Chrome', 19))) { // is Mobile, iOS and not Safari 6 or Chrome 19
		return {
			type: 'm_apple',
			desc: 'browserwarning_mobile_apple_text',
			browsers: ['Mobile-Safari', 'Chrome'],
			installed: 'Mobile-Safari'
		}
	} else if (GLU.device.isTouchOnly() && GLU.os.is('Android') && GLU.os.version() < 4) {// is Mobile, Android and version < 4
		return {
			type: 'm_android_old',
			desc: 'browserwarning_mobile_android_version_text',
			browsers: [],
			osVersion: '4.0'
		}
	} else if (GLU.device.isTouchOnly() && GLU.os.is('Android') && !validateBrowser('Chrome', 19)) { // is Mobile, Android and not Chrome 19
		return {
			type: 'm_android',
			desc: 'browserwarning_mobile_android_text',
			browsers: [ 'Chrome' ]
		}
	} else if (GLU.device.isTouchOnly()) { // for all the other Mobile situations
		if (GLU.os.is('iOS')) {
			return {
				type: 'd_unknown',
				desc: 'browserwarning_mobile_apple_text',
				browsers: ['Chrome', 'Mobile-Safari'],
				installed: 'Mobile-Safari'
			}
		} else if (GLU.os.is('Android')) {
			return {
				type: 'd_unknown',
				desc: 'browserwarning_mobile_android_text',
				browsers: ['Chrome', 'Explorer', 'Firefox']
			}
		} else if (GLU.os.is('Windows')) {
			return {
				type: 'd_unknown',
				desc: 'browserwarning_mobile_windows_text',
				browsers: ['Chrome', 'Explorer', 'Firefox']
			}
		} else if (GLU.browser.is('Firefox')) {
			return {
				type: 'd_unknown',
				desc: 'browserwarning_mobile_unknown_text',
				browsers: ['Chrome', 'Explorer']
			}
		}
		return {
			type: 'm_unknown',
			desc: 'browserwarning_mobile_unknown_text',
			browsers: ['Chrome', 'Mobile-Safari', 'Explorer']
		}
	}
}

function checkNewerVersions(currentVersion, comparedVersion) {
	if (currentVersion == undefined) {
		return false //nothing to compare here
	}

	if (currentVersion.indexOf('.') === -1) {
		return currentVersion >= comparedVersion
	}

	var v = currentVersion.split('.')
	var vComp = comparedVersion.split('.')

	var len = Math.max(v.length, vComp.length)
	if (v.length < vComp.length) {
		v = normalizeArray(v, len)
	} else if (v.length > vComp.length) {
		vComp =  normalizeArray(vComp, len)
	}

	var result = true

	for (var i = 0; i < len; ++i) {
		var current = parseInt(v[i], 10)
		var compared = parseInt(vComp[i], 10)
		if (current == compared) {
			continue
		} else {
			result = current > compared
			break
		}
	}

	return result
}

function normalizeArray(arr, len) {
	if (arr.length == len) {
		return arr
	} else {
		arr.push(0)
	}
}

function createIcon(displayBrowser) {
	return (GLU.os.is('Mac') &&
		displayBrowser == 'Safari' &&
		checkNewerVersions(GLU.os.version(true), '10.10')) ?
			(displayBrowser.toLowerCase() + '_10_10') :
			((GLU.device.isTouchOnly() && GLU.os.is('iOS') && GLU.os.version() >= 7 && displayBrowser == 'Mobile-Safari') ?
				(displayBrowser.toLowerCase() + '_iOS7+') :
				((isIE6Or7 ? 'ie_' : '') + displayBrowser.toLowerCase()))
}

function getBrowsersUrl(browser) {
	var isIOSChromeV6Plus = GLU.device.isTouchOnly() &&
		GLU.os.is('iOS') &&
		GLU.os.version() >= 6 &&
		browser == 'Chrome'

	var isAndroidChromeV4Plus = (GLU.device.isTouchOnly() &&
		GLU.os.is('Android') &&
		GLU.os.version() >= 4 &&
		browser == 'Chrome')

	return isIOSChromeV6Plus ?
			browsers[browser].urlAppStore :
				(isAndroidChromeV4Plus ?
					browsers[browser].urlPlayStore :
					browsers[browser].url)
}

function displayBrowserList(c) {
	var o = ''
	for (var i = 0; i < c.browsers.length; i++) {
		if (!GLU.os.is('Mac') && c.browsers[i] == 'Safari') {
			continue
		}

		o += '<div id="browser' + i + '" class="gdkSupportedBrowser browser_' + c.browsers[i] + '"' + (c.type == 'm_unknown' ? ' style="max-width: 300px; margin: 0px auto 24px;' + (c.browsers.length > 1 ? ' text-align: left' : '') + '"' : '') + '>'
		o += '<img src="' + GLU.com.settings.getEnv('glu').baseUrl + '/extras/unsupported/images/icons/' + createIcon(c.browsers[i]) + '-icon.png" class="gdkSupportedBrowserIcon"' + (c.browsers.length > 1 ? ' style="margin-left: 0px"' : '') + '">'
		o += '<div class="gdkSupportedBrowserName">' + GLU.com.getSystemString(browsers[c.browsers[i]].translationString) + '</div>'

		if (c.browsers[i] == c.upgrade) {
			buttonText = GLU.com.getSystemString('browserwarning_upgrade_button')
		} else if (c.installed == c.browsers[i]) {
			buttonText = GLU.com.getSystemString('browserwarning_installed_label')
		} else {
			buttonText = GLU.com.getSystemString('browserwarning_download_button')
		}
		if (c.type !== 'm_unknown') {
			o += (c.installed != c.browsers[i] ? '<a href="' + getBrowsersUrl(c.browsers[i]) + '" target="_blank" class="gdkButtonLink">' : '')
			o += '<button class="gdkButton gdkButtonWhite"' + (c.installed == c.browsers[i] ? ' disabled="disabled"' : '') + '>'
			o += '<span class="gdkButtonText" style="width:auto">' + buttonText + '</span></button>'
			if (c.installed !== c.browsers[i]) {
				o += '</a>'
			}
		}
		o += '</div>'
	}
	return o
}

templateContent = currentUnsupportedSituation()

unsupportedTemplateButtons = displayBrowserList(templateContent)

function getTitleSitation() {
	if (GLU.device.isTouchOnly() && GLU.os.is('iOS') && GLU.os.version() < 6) {
		return GLU.com.getSystemString('browserwarning_ios_title')
	} else if (GLU.device.isTouchOnly() && GLU.os.is('Android') && GLU.os.version() < 4) {
		return GLU.com.getSystemString('browserwarning_android_title')
	} else {
		return GLU.com.getSystemString('browserwarning_desktop_title')
	}
}

unsupportedTemplate = ''
unsupportedTemplate += '<div class="gdkPanelHeader">'
unsupportedTemplate +=	'<h1 class="gdkPanelHeaderTitle" style="padding-bottom: 50px;">' + getTitleSitation() + '</h1>'
unsupportedTemplate += '</div>'
unsupportedTemplate += '<div class="gdkPanelContent">'
unsupportedTemplate += 	'<div class="gdkTableWrap">'
unsupportedTemplate += 		'<div class="gdkTableCell"' + (unsupportedTemplateButtons.length == 0 ? ' style="height: 180px"' : '')  + '>'
unsupportedTemplate += 			'<div class="gdkUnsupportedDesc">' + GLU.com.getSystemString(templateContent.desc, templateContent.osVersion) + '</div>'
unsupportedTemplate += 				unsupportedTemplateButtons
unsupportedTemplate += 			'</div>'
unsupportedTemplate += 			'<div class="gdkTableRow"></div>'
unsupportedTemplate += 		'</div>'
unsupportedTemplate += 	'</div>'
unsupportedTemplate += '<!--[if IE 9]>'
unsupportedTemplate += '<style type="text/css">'
unsupportedTemplate += 	'.gdkPanelContent{'
unsupportedTemplate += 		'width: 100%;'
unsupportedTemplate += 	'}'
unsupportedTemplate += '</style>'
unsupportedTemplate += '<![endif]-->'
unsupportedTemplate += '<style> body { background: transparent !important; } </style>'

content = document.createElement('div')
content.id = 'gdkUnsupportedDeviceBrowser'
content.className = 'gdkPanel odoboGDK'
content.innerHTML = unsupportedTemplate
document.getElementsByTagName('body')[0].appendChild(content)

link = document.createElement('link')
link.rel = 'stylesheet'
link.type = 'text/css'
link.href = GLU.com.settings.getEnv('glu').baseUrl + '/extras/unsupported/unsupported' + (isIE6Or7 ? '_ie6_7' : '') + '.css'
document.getElementsByTagName('head')[0].appendChild(link)

// Scroll and text fixes for devices using firefox
if (GLU.device.isTouchOnly() && GLU.browser.is('Firefox')) {
	var downloadButton = document.getElementsByClassName('gdkSupportedBrowser')
	document.getElementsByClassName('gdkPanelHeaderTitle')[0].style.lineHeight = 'normal'
	document.getElementById('gdkUnsupportedDeviceBrowser').style.overflow = 'auto'

	for (i = 0; i < downloadButton.length; i++) {
		downloadButton[i].style.textAlign = 'center'
	}
}

// IE 6 & 7 styling fixes, GPAS-20084
if (isIE6Or7) {
	var downloadButton = document.getElementsByClassName('gdkButton gdkButtonWhite')
	var rowItem = document.getElementsByClassName('gdkSupportedBrowser')

	for (i = 0; i < rowItem.length; i++) {
		downloadButton[i].style.float = 'right'
		rowItem[i].style.marginTop = '15px'
		rowItem[i].style.textAlign = 'left'
	}
}

// IE 6/7/8 compat
if (GLU.browser.name() == 'Explorer' && (GLU.browser.version() < '9')) {
	linkEls = document.getElementsByTagName('a')
	for (i = 0; i < linkEls.length; i++) {
		linkEls[i].attachEvent('onclick', (function(el) {
			return function() {
				window.open(el, '_blank')
				return false
			}
		})(linkEls[i]))
	}
}

// Remove IE10+ download for Vista, XP
if (GLU.os.name() == 'Windows' && GLU.os.version() < 6.1) {
	var elOpts = document.getElementsByClassName('browser_Explorer')

	if (elOpts[0]) {
		elOpts[0].parentNode.removeChild(elOpts[0])
	}
}

// Remove Safari until Mac 10.7+
if (GLU.os.name() == 'Mac' && !checkNewerVersions(GLU.os.version(), '10.6')) {
	var elOpts = document.getElementsByClassName('browser_Safari')

	if (elOpts[0]) {
		elOpts[0].parentNode.removeChild(elOpts[0])
	}
}
