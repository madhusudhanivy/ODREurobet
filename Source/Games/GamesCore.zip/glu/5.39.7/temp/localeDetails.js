gdkDefine("locale:localeDetails.json", [], function() { 
 return {
	"af": {
		"currencyTemplate": "{SYMBOL}-{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "yyyy-mm-dd"
	},
	"bg": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"zh-Hans": {
		"currencyTemplate": " {SYMBOL}-{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "yyyy/mm/dd"
	},
	"zh-Hant": {
		"currencyTemplate": " {SYMBOL}-{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "yyyy/mm/dd"
	},
	"cs": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd. mm. yyyy"
	},
	"da": {
		"currencyTemplate": "{SYMBOL} -{NUMBER}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd-mm-yyyy"
	},
	"en": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "dd/mm/yyyy"
	},
	"fr": {
		"currencyTemplate": " -{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd/mm/yyyy"
	},
	"de": {
		"currencyTemplate": " -{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"el": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd/mm/yyyy"
	},
	"hu": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "yyyy. mm. dd."
	},
	"it": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd/mm/yyyy"
	},
	"ja": {
		"currencyTemplate": "{SYMBOL} -{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "yyyy/mm/dd"
	},
	"no": {
		"currencyTemplate": "{SYMBOL} -{NUMBER}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"pl": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"pt": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd/mm/yyyy"
	},
	"ro": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"ru": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"sk": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd. mm. yyyy"
	},
	"es": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd/mm/yyyy"
	},
	"sv": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "yyyy-mm-dd"
	},
	"nl": {
		"currencyTemplate": "{SYMBOL} -{NUMBER}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd-mm-yy"
	},
	"et": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"fi": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"pt-BR": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd/mm/yyyy"
	},
	"tr": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"sl": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd. mm. yyyy"
	},
	"lv": {
		"currencyTemplate": "{SYMBOL} -{NUMBER}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy."
	},
	"lt": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "yyyy-mm-dd"
	},
	"hr": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd.mm.yy."
	},
	"sr": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd. mm. yyyy"
	},
	"th": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "dd/mm/yyyy"
	},
	"ko": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "yyyy-mm-dd"
	},
	"tl": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "dd-mm-yyyy"
	},
	"km": {
		"currencyTemplate": "-{NUMBER}{SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd/mm/yyyy"
	},
	"vi": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd/mm/yyyy"
	},
	"id": {
		"currencyTemplate": "- {SYMBOL}{NUMBER}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd/mm/yyyy"
	},
	"ms": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "dd/mm/yyyy"
	},
	"uk": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"hi": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "dd/mm/yyyy"
	},
	"es-MX": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "dd/mm/yyyy"
	},
	"az": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"hy": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###.##",
		"dateFormat": "dd.mm.yyyy"
	},
	"ka": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###.##",
		"dateFormat": "dd.mm.yyyy"
	},
	"mk": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "#.###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"uz": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "dd.mm.yyyy"
	},
	"mn": {
		"currencyTemplate": "-{NUMBER} {SYMBOL}",
		"numberFormat": "# ###,##",
		"dateFormat": "yyyy-mm-dd"
	},
	"xx": {
		"currencyTemplate": "-{SYMBOL}{NUMBER}",
		"numberFormat": "#,###.##",
		"dateFormat": "dd/mm/yyyy"
	}
}
 
 })