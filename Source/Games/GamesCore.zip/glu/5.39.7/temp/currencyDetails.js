gdkDefine("locale:currencyDetails.json", [], function() { 
 return {
	"AFN": {
		"currencyCode": "AFN",
		"currencySymbol": "؋",
		"currencyExponent": "2"
	},
	"ALL": {
		"currencyCode": "ALL",
		"currencySymbol": "Lek",
		"currencyExponent": "2"
	},
	"ANG": {
		"currencyCode": "ANG",
		"currencySymbol": "ƒ",
		"currencyExponent": "2"
	},
	"ARS": {
		"currencyCode": "ARS",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"AUD": {
		"currencyCode": "AUD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"AWG": {
		"currencyCode": "AWG",
		"currencySymbol": "ƒ",
		"currencyExponent": "2"
	},
	"AZN": {
		"currencyCode": "AZN",
		"currencySymbol": "ман",
		"currencyExponent": "2"
	},
	"BAM": {
		"currencyCode": "BAM",
		"currencySymbol": "KM",
		"currencyExponent": "2"
	},
	"BBD": {
		"currencyCode": "BBD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"BGN": {
		"currencyCode": "BGN",
		"currencySymbol": "лв",
		"currencyExponent": "2"
	},
	"BMD": {
		"currencyCode": "BMD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"BND": {
		"currencyCode": "BND",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"BOB": {
		"currencyCode": "BOB",
		"currencySymbol": "$b",
		"currencyExponent": "2"
	},
	"BRL": {
		"currencyCode": "BRL",
		"currencySymbol": "R$",
		"currencyExponent": "2"
	},
	"BSD": {
		"currencyCode": "BSD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"BWP": {
		"currencyCode": "BWP",
		"currencySymbol": "P",
		"currencyExponent": "2"
	},
	"BYR": {
		"currencyCode": "BYR",
		"currencySymbol": "p.",
		"currencyExponent": "0"
	},
	"BZD": {
		"currencyCode": "BZD",
		"currencySymbol": "BZ$",
		"currencyExponent": "2"
	},
	"CAD": {
		"currencyCode": "CAD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"CHF": {
		"currencyCode": "CHF",
		"currencySymbol": "CHF",
		"currencyExponent": "2"
	},
	"CLP": {
		"currencyCode": "CLP",
		"currencySymbol": "$",
		"currencyExponent": "0"
	},
	"CNY": {
		"currencyCode": "CNY",
		"currencySymbol": "¥",
		"currencyExponent": "2"
	},
	"COP": {
		"currencyCode": "COP",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"CRC": {
		"currencyCode": "CRC",
		"currencySymbol": "₡",
		"currencyExponent": "2"
	},
	"CUP": {
		"currencyCode": "CUP",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"CZK": {
		"currencyCode": "CZK",
		"currencySymbol": "Kč",
		"currencyExponent": "2"
	},
	"DKK": {
		"currencyCode": "DKK",
		"currencySymbol": "kr",
		"currencyExponent": "2"
	},
	"DOP": {
		"currencyCode": "DOP",
		"currencySymbol": "RD$",
		"currencyExponent": "2"
	},
	"EGP": {
		"currencyCode": "EGP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"EUR": {
		"currencyCode": "EUR",
		"currencySymbol": "€",
		"currencyExponent": "2"
	},
	"FJD": {
		"currencyCode": "FJD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"FKP": {
		"currencyCode": "FKP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"GBP": {
		"currencyCode": "GBP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"GEL": {
		"currencyCode": "GEL",
		"currencySymbol": "ლ",
		"currencyExponent": "2"
	},
	"GGP": {
		"currencyCode": "GGP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"GHC": {
		"currencyCode": "GHC",
		"currencySymbol": "¢",
		"currencyExponent": "2"
	},
	"GIP": {
		"currencyCode": "GIP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"GTQ": {
		"currencyCode": "GTQ",
		"currencySymbol": "Q",
		"currencyExponent": "2"
	},
	"GYD": {
		"currencyCode": "GYD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"HKD": {
		"currencyCode": "HKD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"HNL": {
		"currencyCode": "HNL",
		"currencySymbol": "L",
		"currencyExponent": "2"
	},
	"HRK": {
		"currencyCode": "HRK",
		"currencySymbol": "kn",
		"currencyExponent": "2"
	},
	"HUF": {
		"currencyCode": "HUF",
		"currencySymbol": "Ft",
		"currencyExponent": "2"
	},
	"IDR": {
		"currencyCode": "IDR",
		"currencySymbol": "Rp",
		"currencyExponent": "2"
	},
	"ILS": {
		"currencyCode": "ILS",
		"currencySymbol": "₪",
		"currencyExponent": "2"
	},
	"IMP": {
		"currencyCode": "IMP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"INR": {
		"currencyCode": "INR",
		"currencySymbol": "Rs",
		"currencyExponent": "2"
	},
	"IRR": {
		"currencyCode": "IRR",
		"currencySymbol": "﷼",
		"currencyExponent": "2"
	},
	"ISK": {
		"currencyCode": "ISK",
		"currencySymbol": "kr",
		"currencyExponent": "2"
	},
	"JEP": {
		"currencyCode": "JEP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"JMD": {
		"currencyCode": "JMD",
		"currencySymbol": "J$",
		"currencyExponent": "2"
	},
	"JPY": {
		"currencyCode": "JPY",
		"currencySymbol": "¥",
		"currencyExponent": "0"
	},
	"KGS": {
		"currencyCode": "KGS",
		"currencySymbol": "лв",
		"currencyExponent": "2"
	},
	"KHR": {
		"currencyCode": "KHR",
		"currencySymbol": "៛",
		"currencyExponent": "2"
	},
	"KPW": {
		"currencyCode": "KPW",
		"currencySymbol": "₩",
		"currencyExponent": "2"
	},
	"KRW": {
		"currencyCode": "KRW",
		"currencySymbol": "₩",
		"currencyExponent": "0"
	},
	"KYD": {
		"currencyCode": "KYD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"KZT": {
		"currencyCode": "KZT",
		"currencySymbol": "л",
		"currencyExponent": "2"
	},
	"LAK": {
		"currencyCode": "LAK",
		"currencySymbol": "₭",
		"currencyExponent": "2"
	},
	"LBP": {
		"currencyCode": "LBP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"LKR": {
		"currencyCode": "LKR",
		"currencySymbol": "₨",
		"currencyExponent": "2"
	},
	"LRD": {
		"currencyCode": "LRD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"LTL": {
		"currencyCode": "LTL",
		"currencySymbol": "vt",
		"currencyExponent": "2"
	},
	"LVL": {
		"currencyCode": "LVL",
		"currencySymbol": "vs",
		"currencyExponent": "2"
	},
	"MKD": {
		"currencyCode": "MKD",
		"currencySymbol": "ден",
		"currencyExponent": "2"
	},
	"MNT": {
		"currencyCode": "MNT",
		"currencySymbol": "₮",
		"currencyExponent": "2"
	},
	"MOP": {
		"currencyCode": "MOP",
		"currencySymbol": "MOP$",
		"currencyExponent": "2"
	},
	"MUR": {
		"currencyCode": "MUR",
		"currencySymbol": "₨",
		"currencyExponent": "2"
	},
	"MXN": {
		"currencyCode": "MXN",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"MYR": {
		"currencyCode": "MYR",
		"currencySymbol": "RM",
		"currencyExponent": "2"
	},
	"MZN": {
		"currencyCode": "MZN",
		"currencySymbol": "MT",
		"currencyExponent": "2"
	},
	"NAD": {
		"currencyCode": "NAD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"NGN": {
		"currencyCode": "NGN",
		"currencySymbol": "₦",
		"currencyExponent": "2"
	},
	"NIO": {
		"currencyCode": "NIO",
		"currencySymbol": "C$",
		"currencyExponent": "2"
	},
	"NOK": {
		"currencyCode": "NOK",
		"currencySymbol": "kr",
		"currencyExponent": "2"
	},
	"NPR": {
		"currencyCode": "NPR",
		"currencySymbol": "₨",
		"currencyExponent": "2"
	},
	"NZD": {
		"currencyCode": "NZD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"OMR": {
		"currencyCode": "OMR",
		"currencySymbol": "﷼",
		"currencyExponent": "3"
	},
	"PAB": {
		"currencyCode": "PAB",
		"currencySymbol": "B/.",
		"currencyExponent": "2"
	},
	"PEN": {
		"currencyCode": "PEN",
		"currencySymbol": "S/.",
		"currencyExponent": "2"
	},
	"PHP": {
		"currencyCode": "PHP",
		"currencySymbol": "₱",
		"currencyExponent": "2"
	},
	"PKR": {
		"currencyCode": "PKR",
		"currencySymbol": "₨",
		"currencyExponent": "2"
	},
	"PLN": {
		"currencyCode": "PLN",
		"currencySymbol": "zł",
		"currencyExponent": "2"
	},
	"PYG": {
		"currencyCode": "PYG",
		"currencySymbol": "Gs",
		"currencyExponent": "0"
	},
	"QAR": {
		"currencyCode": "QAR",
		"currencySymbol": "﷼",
		"currencyExponent": "2"
	},
	"RON": {
		"currencyCode": "RON",
		"currencySymbol": "RON",
		"currencyExponent": "2"
	},
	"RSD": {
		"currencyCode": "RSD",
		"currencySymbol": "Дин.",
		"currencyExponent": "2"
	},
	"RUB": {
		"currencyCode": "RUB",
		"currencySymbol": "руб",
		"currencyExponent": "2"
	},
	"SAR": {
		"currencyCode": "SAR",
		"currencySymbol": "﷼",
		"currencyExponent": "2"
	},
	"SBD": {
		"currencyCode": "SBD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"SCR": {
		"currencyCode": "SCR",
		"currencySymbol": "₨",
		"currencyExponent": "2"
	},
	"SEK": {
		"currencyCode": "SEK",
		"currencySymbol": "kr",
		"currencyExponent": "2"
	},
	"SGD": {
		"currencyCode": "SGD",
		"currencySymbol": "S$",
		"currencyExponent": "2"
	},
	"SHP": {
		"currencyCode": "SHP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"SOS": {
		"currencyCode": "SOS",
		"currencySymbol": "S",
		"currencyExponent": "2"
	},
	"SRD": {
		"currencyCode": "SRD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"SVC": {
		"currencyCode": "SVC",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"SYP": {
		"currencyCode": "SYP",
		"currencySymbol": "£",
		"currencyExponent": "2"
	},
	"THB": {
		"currencyCode": "THB",
		"currencySymbol": "฿",
		"currencyExponent": "2"
	},
	"TRY": {
		"currencyCode": "TRY",
		"currencySymbol": "TRY",
		"currencyExponent": "2"
	},
	"TTD": {
		"currencyCode": "TTD",
		"currencySymbol": "TT$",
		"currencyExponent": "2"
	},
	"TVD": {
		"currencyCode": "TVD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"TWD": {
		"currencyCode": "TWD",
		"currencySymbol": "NT$",
		"currencyExponent": "2"
	},
	"TZS": {
		"currencyCode": "TZS",
		"currencySymbol": "TSh",
		"currencyExponent": "2"
	},
	"UAH": {
		"currencyCode": "UAH",
		"currencySymbol": "₴",
		"currencyExponent": "2"
	},
	"USD": {
		"currencyCode": "USD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"UYU": {
		"currencyCode": "UYU",
		"currencySymbol": "$U",
		"currencyExponent": "2"
	},
	"UZS": {
		"currencyCode": "UZS",
		"currencySymbol": "лв",
		"currencyExponent": "2"
	},
	"VEF": {
		"currencyCode": "VEF",
		"currencySymbol": "Bs",
		"currencyExponent": "2"
	},
	"VND": {
		"currencyCode": "VND",
		"currencySymbol": "₫",
		"currencyExponent": "0"
	},
	"XCD": {
		"currencyCode": "XCD",
		"currencySymbol": "$",
		"currencyExponent": "2"
	},
	"XOF": {
		"currencyCode": "XOF",
		"currencySymbol": "₣",
		"currencyExponent": "0"
	},
	"YER": {
		"currencyCode": "YER",
		"currencySymbol": "﷼",
		"currencyExponent": "2"
	},
	"ZAR": {
		"currencyCode": "ZAR",
		"currencySymbol": "R",
		"currencyExponent": "2"
	},
	"ZWD": {
		"currencyCode": "ZWD",
		"currencySymbol": "Z$",
		"currencyExponent": "2"
	},
	"VDO": {
		"currencyCode": "VDO",
		"currencySymbol": "₫",
		"currencyExponent": "0"
	}
}
 
 })